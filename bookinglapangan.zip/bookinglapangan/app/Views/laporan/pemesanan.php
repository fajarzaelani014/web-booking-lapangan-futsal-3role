<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pemesanan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            background-color: #343a40;
            color: white;
            padding: 20px;
            overflow-y: auto;
        }

        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 15px;
        }

        .container-content {
            margin-left: 260px;
            padding: 20px;
            width: calc(100% - 260px);
        }

        .card {
            padding: 20px;
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .container-content {
                margin-left: 0;
                width: 100%;
                padding: 15px;
            }
        }

        @media print {
            body * {
                visibility: hidden;
            }

            #printArea,
            #printArea * {
                visibility: visible;
            }

            #printArea {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->

        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="https://ligaayo.com/" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <div class="container-content">
        <div class="card p-4">
            <h2 class="text-center"><i class="bi bi-cash-stack"></i> Data Keuangan</h2>

            <!-- Form Filter -->
            <form method="GET" action="">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="tanggal" class="form-label">Pilih Tanggal</label>
                        <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $_GET['tanggal'] ?? '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="bulan" class="form-label">Pilih Bulan</label>
                        <select class="form-control" name="bulan" id="bulan">
                            <option value="">Semua</option>
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= (isset($_GET['bulan']) && $_GET['bulan'] == $i) ? 'selected' : '' ?>>
                                    <?= date('F', mktime(0, 0, 0, $i, 1)) ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="tahun" class="form-label">Pilih Tahun</label>
                        <select class="form-control" name="tahun" id="tahun">
                            <option value="">Semua</option>
                            <?php
                            $tahunSekarang = date('Y');
                            for ($i = $tahunSekarang; $i >= 2020; $i--): ?>
                                <option value="<?= $i ?>" <?= (isset($_GET['tahun']) && $_GET['tahun'] == $i) ? 'selected' : '' ?>>
                                    <?= $i ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-filter"></i> Filter</button>
                    <a href="?" class="btn btn-secondary"><i class="bi bi-arrow-clockwise"></i> Reset</a>
                    <button type="button" class="btn btn-success" onclick="printTable()"><i class="bi bi-printer"></i> Cetak</button>
                </div>
            </form>
        </div>

        <!-- Print Area -->
        <div id="printArea">
            <div class="card shadow mt-4 mb-5">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0">Laporan Keuangan</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered text-center">
                            <thead class="table-primary">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lapangan</th>
                                    <th>Harga Per Jam</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $totalHarga = 0;
                                $no = 1;
                                foreach ($laporan as $row):
                                    $totalHarga += $row['harga_per_jam'];
                                ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= esc($row['nama_lapangan']) ?></td>
                                        <td><strong>Rp <?= number_format($row['harga_per_jam'], 0, ',', '.') ?></strong></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <tr>
                                    <td colspan="2" class="text-end"><strong>Total</strong></td>
                                    <td><strong>Rp <?= number_format($totalHarga, 0, ',', '.') ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Script -->
    <script>
        function printTable() {
            window.print();
        }
    </script>

</body>

</html>