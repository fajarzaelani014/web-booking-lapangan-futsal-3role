<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Harga Lapangan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Tambah Harga Lapangan</h2>
    <form action="<?= base_url('harga/store') ?>" method="post">
        <div class="mb-3">
            <label for="nama_lapangan" class="form-label">Nama Lapangan</label>
            <input type="text" name="nama_lapangan" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="harga_per_jam" class="form-label">Harga per Jam</label>
            <input type="text" name="harga_per_jam" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="<?= base_url('harga') ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
