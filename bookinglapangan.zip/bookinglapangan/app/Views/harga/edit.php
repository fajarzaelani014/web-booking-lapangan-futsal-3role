<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Lapangan</title>
</head>

<body>
    <div class="container mt-4">
        <h2>Edit Harga Lapangan</h2>
        <form action="<?= base_url('harga/update/' . $harga['id_harga']) ?>" method="post">
            <div class="mb-3">
                <label for="nama_lapangan" class="form-label">Nama Lapangan</label>
                <input type="text" class="form-control" name="nama_lapangan" value="<?= $harga['nama_lapangan'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="harga_per_jam" class="form-label">Harga per Jam</label>
                <input type="text" class="form-control" name="harga_per_jam" value="<?= $harga['harga_per_jam'] ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
            <a href="<?= base_url('harga') ?>" class="btn btn-secondary">Batal</a>
        </form>
    </div>

</body>

</html>