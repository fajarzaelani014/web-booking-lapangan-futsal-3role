<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .register-container {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
            color: white;
        }
        .register-container h1 {
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .register-container input, 
        .register-container select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            transition: 0.3s;
            background: rgba(255, 255, 255, 0.5);
            color: #333;
        }
        .register-container input:focus, 
        .register-container select:focus {
            outline: none;
            box-shadow: 0 0 8px rgba(255, 255, 255, 0.5);
        }
        .register-container button {
            width: 100%;
            padding: 12px;
            background: #ff7eb3;
            border: none;
            color: white;
            font-size: 18px;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.3s;
            font-weight: 600;
        }
        .register-container button:hover {
            background: #ff4d79;
        }
        .login-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .login-link a {
            color: #ff7eb3;
            text-decoration: none;
            font-weight: 600;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h1>Register</h1>
        <form action="<?= site_url('auth/registerProcess') ?>" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <input type="text" name="nama" placeholder="Nama" required>
            <input type="email" name="email" placeholder="Email" required>
            <select name="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="admin">Admin</option>
                <option value="pengelola">Pengelola</option>
                <option value="penyewa">Penyewa</option>
            </select>
            <button type="submit">Register</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="<?= base_url('auth/login'); ?>">Login</a>
        </div>
    </div>
</body>
</html>