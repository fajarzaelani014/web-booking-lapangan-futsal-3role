<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-wrapper {
            display: flex;
            width: 800px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
        }

        .login-form {
            flex: 1;
            padding: 30px;
            background-color: #ffffff;
        }

        .login-form h2 {
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .login-form input {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 25px;
            font-size: 14px;
        }

        .login-form .btn-login {
            width: 100%;
            padding: 12px;
            border-radius: 25px;
            background: linear-gradient(90deg, #fc466b, #3f5efb);
            color: #fff;
            font-weight: bold;
            border: none;
            font-size: 16px;
            cursor: pointer;
        }

        .login-form .btn-login:hover {
            background: linear-gradient(90deg, #d53369, #2b5876);
        }

        .login-form .remember {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 14px;
        }

        .login-form .remember input {
            margin-right: 8px;
        }

        .login-info {
            flex: 1;
            background: linear-gradient(90deg, #fc466b, #3f5efb);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .login-info h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .login-info a {
            color: #fff;
            font-weight: bold;
            padding: 10px 25px;
            border: 2px solid #fff;
            border-radius: 25px;
            text-decoration: none;
        }

        .login-info a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
    </style>
</head>

<body>
    <div class="login-wrapper">
        <div class="login-form">
            <h2>Sign In</h2>

            <?php if (session()->getFlashdata('error')) : ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?= base_url('auth/loginProcess') ?>">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <div class="remember">
                    <label>
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                    <a href="#">Forgot Password?</a>
                </div>
                <button type="submit" class="btn-login">Sign In</button>
            </form>
        </div>
        <div class="login-info">
            <h2>Welcome to Login</h2>
            <p>Don't have an account?</p>
            <a href="<?= base_url('auth/register') ?>">Sign Up</a>
        </div>
    </div>
</body>

</html>