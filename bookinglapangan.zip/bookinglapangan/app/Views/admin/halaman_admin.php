<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #1f2235;
            color: white;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            font-size: 16px;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar .active {
            background-color: #6468a3;
            border-radius: 8px;
        }

        .sidebar i {
            margin-right: 10px;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            width: 100%;
        }

        .section-title {
            font-size: 14px;
            text-transform: uppercase;
            padding: 10px 20px;
            color: #8b8fa5;
            font-weight: bold;
        }

        .chart-container {
            width: 100%;
            max-width: 600px;
            margin: auto;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
            overflow-y: auto;
            /* Enable scrolling when content exceeds the height */
        }

        /* Styling for each sidebar item */
        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;

            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
            text-decoration: none;
        }

        /* Section title for better separation */
        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        /* Optional: Customize sidebar title (optional) */
        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
            text-decoration: none;
        }

        /* Styling for the scrollable content */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        /* Adjustments for the layout */
        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->

        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="https://ligaayo.com/" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="row">
            <!-- Card Statistik -->
            <div class="col-md-4">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-futbol"></i> Lapangan</h5>
                        <h3><?= $jumlahLapangan ?? 0 ?></h3>
                        <small>Total Lapangan yang tersedia</small>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-white bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-calendar-alt"></i> Jadwal</h5>
                        <h3><?= $jumlahJadwal ?? 0 ?></h3>
                        <small>Total Jadwal yang dibuat</small>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-user-check"></i> Pemesan</h5>
                        <h3><?= $jumlahPemesanan ?? 0 ?></h3>
                        <small>Total Pemesan yang terdaftar</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="container text-center mt-5">
            <h1 class="fw-bold text-primary">⚽Selamat Datang di Sistem Booking Lapangan Futsal!⚽</h1>
            <p class="mt-3 fs-5 text-muted">
                Temukan dan pesan lapangan terbaik untuk pertandingan atau latihan tim Anda.
                Nikmati kemudahan dalam mengelola jadwal, pemesanan, dan informasi liga dengan cepat dan mudah.
            </p>
            <div class="mt-4">
                <a href="<?= site_url('lapangan/data_lapangan') ?>" class="btn btn-success btn-lg me-3">
                    <i class="bi bi-geo-alt"></i> Lihat Lapangan
                </a>
                <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="btn btn-primary btn-lg">
                    <i class="bi bi-calendar-check"></i> Buat Pemesanan
                </a>
            </div>
        </div>

        <!-- Statistik Booking Lapangan -->
        <div class="container mt-5">
            <h3 class="text-center">📊 Statistik Booking Lapangan</h3>


            <!-- Grafik Statistik -->
            <div class="chart-container">
                <canvas id="dashboardChart"></canvas>
            </div>

            <!-- Tabel Statistik -->
            <div class="mt-4">
                <h4 class="text-center">📋 Data Statistik</h4>
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Lapangan</td>
                            <td><?= $jumlahLapangan ?? 0 ?></td>
                        </tr>
                        <tr>
                            <td>Jadwal</td>
                            <td><?= $jumlahJadwal ?? 0 ?></td>
                        </tr>
                        <tr>
                            <td>Pemesanan</td>
                            <td><?= $jumlahPemesanan ?? 0 ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Script Chart.js -->
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var jumlahLapangan = <?= $jumlahLapangan ?? 0 ?>;
                var jumlahJadwal = <?= $jumlahJadwal ?? 0 ?>;
                var jumlahPemesanan = <?= $jumlahPemesanan ?? 0 ?>;

                var ctx = document.getElementById('dashboardChart').getContext('2d');
                var dashboardChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Lapangan', 'Jadwal', 'Pemesanan'],
                        datasets: [{
                            label: 'Jumlah Data',
                            data: [jumlahLapangan, jumlahJadwal, jumlahPemesanan],
                            backgroundColor: ['#28a745', '#007bff', '#ffc107'],
                            borderColor: ['#218838', '#0056b3', '#d39e00'],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            });
        </script>

        <!-- Tambahkan FontAwesome & Bootstrap -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>

</html>