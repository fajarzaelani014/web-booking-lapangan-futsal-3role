<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            min-height: 100vh;
            background-color: #f8f9fa;
            display: flex;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            background-color: #343a40;
            color: white;
            padding-top: 20px;
            overflow-y: auto;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar .active {
            background-color: #007bff;
            border-radius: 8px;
        }

        .sidebar i {
            margin-right: 10px;
        }

        .content {
            margin-left: 260px;
            padding: 20px;
            width: 100%;
        }

        .table-responsive {
            overflow-x: auto;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
            overflow-y: auto;
            /* Enable scrolling when content exceeds the height */
        }

        /* Styling for each sidebar item */
        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
        }

        /* Section title for better separation */
        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        /* Optional: Customize sidebar title (optional) */
        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Styling for the scrollable content */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        /* Adjustments for the layout */
        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->

        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cart me-2"></i> Pemesanan
        </a>
        <a href="<?= site_url('liga/liga_ayo') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>
        <a href="https://ligaayo.com/" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Harga
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/keuangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <div class="content container-fluid">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Profil Pengguna</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($user)): ?>
                    <p><strong>Username:</strong> <?= esc($user['username'] ?? 'Tidak tersedia') ?></p>
                    <p><strong>Nama:</strong> <?= esc($user['nama'] ?? 'Tidak tersedia') ?></p>
                    <p><strong>Email:</strong> <?= esc($user['email'] ?? 'Tidak tersedia') ?></p>
                    <p><strong>Role:</strong> <?= esc(ucfirst($user['role'] ?? 'Tidak ada')) ?></p>

                    <p><strong>Password:</strong>
                        <input type="password" value="<?= esc($user['password'] ?? '') ?>" id="passwordField" class="form-control d-inline-block w-auto" readonly>
                        <button type="button" class="btn btn-secondary btn-sm" onclick="togglePassword()">Tampilkan</button>
                    </p>

                    <a href="<?= site_url('admin/edit_profil_admin') ?>" class="btn btn-warning">Edit Profil</a>
                    <a href="<?= site_url('/logout') ?>" class="btn btn-danger">Logout</a>
                <?php else: ?>
                    <p class="text-danger">Data pengguna tidak ditemukan.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("passwordField");
            passwordField.type = passwordField.type === "password" ? "text" : "password";
        }
    </script>
</body>

</html>