<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Jadwal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
            overflow-y: auto;
        }

        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
        }

        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
        }

        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }

        /* Adjustments for main content */
        .container {
            margin-left: 270px;
            padding: 20px;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-secondary,
        .btn-primary {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->

        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="https://ligaayo.com/" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <!-- Main Content -->
    <div class="container">
        <h1 class="text-center mb-4">Tambah Jadwal</h1>
        <form action="<?= site_url('jadwal/store') ?>" method="post">
            <div class="mb-3">
                <label for="idLapangan" class="form-label">Lapangan</label>
                <select class="form-select" id="idLapangan" name="id_lapangan" required>
                    <option value="" disabled selected>Pilih Lapangan</option>
                    <?php foreach ($lapangan as $item): ?>
                        <option value="<?= esc($item['id_lapangan']) ?>">
                            <?= esc($item['nama_lapangan']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" required>
            </div>

            <div class="mb-3">
                <label for="jam" class="form-label">Jam</label>
                <div id="jamFields">
                    <div class="row g-2 mb-2">
                        <div class="col">
                            <input type="time" class="form-control" name="jam_mulai[]" required>
                        </div>
                        <div class="col">
                            <input type="time" class="form-control" name="jam_selesai[]" required>
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-success add-row">+</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="Available">Available</option>
                    <option value="Booked">Booked</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?= site_url('jadwal/index') ?>" class="btn btn-secondary">Batal</a>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const jamFields = document.getElementById('jamFields');

            jamFields.addEventListener('click', (e) => {
                if (e.target.classList.contains('add-row')) {
                    e.preventDefault();
                    const newRow = document.createElement('div');
                    newRow.classList.add('row', 'g-2', 'mb-2');
                    newRow.innerHTML = `
                        <div class="col">
                            <input type="time" class="form-control" name="jam_mulai[]" required>
                        </div>
                        <div class="col">
                            <input type="time" class="form-control" name="jam_selesai[]" required>
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-danger remove-row">-</button>
                        </div>
                    `;
                    jamFields.appendChild(newRow);
                } else if (e.target.classList.contains('remove-row')) {
                    e.preventDefault();
                    e.target.closest('.row').remove();
                }
            });
        });
    </script>
</body>

</html>