<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Jadwal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
            overflow-y: auto;
        }

        /* Styling for each sidebar item */
        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
        }

        /* Section title for better separation */
        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Styling for the scrollable content */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        /* Layout adjustments */
        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }

        /* Main content adjustments */
        .container {
            margin-left: 260px;
            /* Adjust for sidebar width */
        }

        .card {
            margin-top: 20px;
        }

        .form-control,
        .form-select {
            width: 100%;
        }

        .btn-success,
        .btn-danger {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->

        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="https://ligaayo.com/" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <div class="container mt-4">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4>Edit Jadwal</h4>
            </div>
            <div class="card-body">
                <form action="<?= site_url('jadwal/update/' . esc($jadwal['id_jadwal'])) ?>" method="post">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td><label for="id_lapangan" class="form-label">Lapangan</label></td>
                                <td>
                                    <select class="form-control" id="id_lapangan" name="id_lapangan" required>
                                        <option value="">Pilih Lapangan</option>
                                        <?php foreach ($lapangan as $l): ?>
                                            <option value="<?= $l['id_lapangan'] ?>" <?= $l['id_lapangan'] == $jadwal['id_lapangan'] ? 'selected' : '' ?>>
                                                <?= esc($l['nama_lapangan']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="tanggal" class="form-label">Tanggal</label></td>
                                <td><input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= esc($jadwal['tanggal']) ?>" required></td>
                            </tr>
                            <tr>
                                <td><label class="form-label">Jam</label></td>
                                <td>
                                    <?php
                                    $jamMulai = is_array($jadwal['jam_mulai']) ? $jadwal['jam_mulai'] : explode(',', $jadwal['jam_mulai']);
                                    $jamSelesai = is_array($jadwal['jam_selesai']) ? $jadwal['jam_selesai'] : explode(',', $jadwal['jam_selesai']);
                                    ?>

                                    <div id="jamFields">
                                        <?php foreach ($jamMulai as $index => $jam_mulai): ?>
                                            <div class="row g-2 mb-2">
                                                <div class="col">
                                                    <input type="time" class="form-control" name="jam_mulai[]" value="<?= esc($jam_mulai) ?>" required>
                                                </div>
                                                <div class="col">
                                                    <input type="time" class="form-control" name="jam_selesai[]" value="<?= esc($jamSelesai[$index] ?? '') ?>" required>
                                                </div>
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-danger remove-row">-</button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>

                                    <button type="button" class="btn btn-success add-row">+ Tambah</button>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="status" class="form-label">Status</label></td>
                                <td>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="Available" <?= esc($jadwal['status']) == 'Available' ? 'selected' : '' ?>>Available</option>
                                        <option value="Booked" <?= esc($jadwal['status']) == 'Booked' ? 'selected' : '' ?>>Booked</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <button type="submit" class="btn btn-primary w-100">Update Jadwal</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const jamFields = document.getElementById('jamFields');

            document.querySelector('.add-row').addEventListener('click', (e) => {
                e.preventDefault();
                const newRow = document.createElement('div');
                newRow.classList.add('row', 'g-2', 'mb-2');
                newRow.innerHTML = `
                    <div class="col">
                        <input type="time" class="form-control" name="jam_mulai[]" required>
                    </div>
                    <div class="col">
                        <input type="time" class="form-control" name="jam_selesai[]" required>
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-danger remove-row">-</button>
                    </div>
                `;
                jamFields.appendChild(newRow);
            });

            jamFields.addEventListener('click', (e) => {
                if (e.target.classList.contains('remove-row')) {
                    e.preventDefault();
                    e.target.closest('.row').remove();
                }
            });
        });
    </script>
</body>

</html>