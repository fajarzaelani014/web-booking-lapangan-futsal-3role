<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Pembayaran</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            max-width: 600px;
        }

        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        .card-title {
            font-weight: 600;
            font-size: 1.25rem;
        }

        .btn-primary {
            background-color: #5cb85c;
            border-color: #5cb85c;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }

        .modal-body p {
            font-size: 1rem;
        }

        .modal-footer .btn {
            font-weight: 600;
        }

        .modal-footer a {
            text-decoration: none;
        }

        .modal-footer a:hover {
            text-decoration: underline;
        }

        /* Responsif Gambar */
        .small-image {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- Menu di sebelah kiri -->
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="https://ligaayo.com/" target="_blank">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>
                <!-- Tombol Logout di sebelah kanan -->
                <div class="d-flex align-items-center ms-auto">
                    <a href="<?= site_url('/logout') ?>" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Checkout Pembayaran</h2>

        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Informasi Jadwal</h5>

                <!-- Gambar Lapangan -->
                <?php if (isset($lapangan) && isset($lapangan['foto'])): ?>
                    <img src="<?= base_url('uploads/' . $lapangan['foto']) ?>" class="small-image mb-3" alt="Foto Lapangan">
                <?php else: ?>
                    <p>Foto lapangan tidak tersedia.</p>
                <?php endif; ?>
                <input type="hidden" name="tanggal" value="<?= esc($_GET['tanggal'] ?? date('Y-m-d')) ?>">
                <p><strong>Tanggal:</strong> <?= esc($_GET['tanggal'] ?? date('Y-m-d')) ?></p>

                <p><strong>Jam Mulai:</strong> <?= esc($jam_mulai) ?></p>
                <p><strong>Jam Selesai:</strong> <?= esc($jam_selesai) ?></p>
                <p class="mb-0"><strong>Harga:</strong> Rp <?= number_format(intval($lapangan['harga_per_jam']), 0, ',', '.') ?> / Jam </p>

                <!-- Tombol Lanjutkan Pembayaran -->
                <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#confirmationModal">
                    Lanjutkan Pembayaran
                </button>
            </div>
        </div>
    </div>

    <!-- Modal Konfirmasi -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmationModalLabel">Konfirmasi Pembayaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Pesanan Anda sudah benar? Anda tidak dapat mengubah detail pesanan setelah melanjutkan ke halaman pembayaran. Tetap lanjutkan?</p>
                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('checkout') ?>" class="btn btn-secondary" data-bs-dismiss="modal">Cek Ulang</a>
                    <a href="<?= base_url('pembayaran/pembayaran?id_jadwal=' . esc($id_jadwal) . '&jam_mulai=' . esc($jam_mulai) . '&jam_selesai=' . esc($jam_selesai) . '&tanggal=' . esc($_GET['tanggal'] ?? date('Y-m-d'))) ?>" class="btn btn-primary">Ya, Lanjutkan</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Tambahkan link ke Bootstrap JS dan Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>