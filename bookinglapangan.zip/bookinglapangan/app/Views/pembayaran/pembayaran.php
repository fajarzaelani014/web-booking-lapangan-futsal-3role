<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">

    <style>
        /* Menggunakan font Poppins di seluruh halaman */
        body {
            background-color: #f5f5f5;
            font-family: 'Poppins', sans-serif;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .total-price {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .secure-payment {
            color: #28a745;
            font-size: 0.9rem;
        }

        .btn-buy {
            background-color: #28a745;
            color: white;
            font-weight: bold;
        }

        .btn-buy:hover {
            background-color: #218838;
        }

        .form-check-label a {
            color: #007bff;
            text-decoration: none;
        }

        .form-check-label a:hover {
            text-decoration: underline;
        }

        /* CSS untuk gambar kecil di kolom kiri */
        .small-image {
            width: 80px;
            /* Ukuran lebar gambar yang diinginkan */
            height: auto;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <a href="<?= site_url('/logout') ?>" class="btn btn-danger ms-2">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Checkout</h2>
        <div class="row">
            <!-- Kolom kiri -->
            <div class="col-md-6">
                <?php if (!empty($lapangan)): ?>
                    <div class="card p-3 mb-3">
                        <h6 class="fw-bold">PRODUCT</h6>
                        <div class="d-flex align-items-center">
                            <!-- Menampilkan foto lapangan yang sesuai -->
                            <img src="<?= base_url('uploads/' . $lapangan['foto']) ?>" class="small-image rounded me-3" alt="Foto Lapangan">
                            <div>
                                <p class="mb-0"><?= esc($lapangan['nama_lapangan']) ?></p>
                                <p class="mb-0">1x</p>
                                <p class="mb-0">Rp <?= number_format(intval($lapangan['harga_per_jam']), 0, ',', '.') ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Kolom kanan -->
            <div class="col-md-6">
                <div class="card p-3 mb-3">
                    <h6 class="fw-bold">PAYMENT DETAIL</h6>
                    <div class="d-flex justify-content-between">
                        <span>Subtotal</span>
                        <span>Rp <?= number_format(intval($lapangan['harga_per_jam']), 0, ',', '.') ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Shipping fee</span>
                        <span>Rp 0</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Discount</span>
                        <span>- Rp 0</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Convenience fee</span>
                        <span>Rp 0</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between total-price">
                        <span>TOTAL</span>
                        <span>Rp <?= number_format(intval($lapangan['harga_per_jam']), 0, ',', '.') ?></span>
                    </div>
                </div>

                <form action="<?= site_url('pemesanan/createPemesanan') ?>" method="POST">
                    <input type="hidden" name="id_lapangan" value="<?= esc($lapangan['id_lapangan'] ?? '') ?>">

                    <!-- Input untuk Nama Pemesan -->
                    <div class="mb-3">
                        <label for="nama_pemesan" class="form-label">Nama Pemesan</label>
                        <input type="text" name="nama_pemesan" id="nama_pemesan" class="form-control" placeholder="Masukkan Nama Pemesan" required>
                    </div>

                    <input type="hidden" name="tanggal" value="<?= esc($_GET['tanggal'] ?? date('Y-m-d')) ?>">
                    <input type="hidden" name="jam_mulai" value="<?= esc($jadwal['jam_mulai'] ?? '') ?>">
                    <input type="hidden" name="jam_selesai" value="<?= esc($jadwal['jam_selesai'] ?? '') ?>">
                    <input type="hidden" name="id_jadwal" value="<?= esc($id_jadwal ?? '') ?>">

                    <button type="submit" class="btn btn-buy w-100">
                        BUY NOW - Rp <?= number_format(intval($lapangan['harga_per_jam'] ?? 0), 0, ',', '.') ?>
                    </button>
                </form>


            </div>
        </div>
    </div>

    <!-- Tambahkan link ke Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>