<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Lapangan Penyewa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .navbar {
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .footer a {
            text-decoration: none;
        }

        .social-icons a {
            margin-right: 10px;
            color: #6c757d;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="https://ligaayo.com/" target="_blank">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>

                <!-- Tombol Profil dengan Dropdown -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> Profil
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/profil') ?>">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/riwayat') ?>">Lihat Riwayat</a></li>
                    </ul>
                </div>

                <a href="<?= site_url('/logout') ?>" class="btn btn-danger ms-2">Logout</a>

            </div>
        </div>
        </div>
    </nav>

    <br>

    <!-- Banner -->
    <div class="bg-danger text-white text-center py-5"
        style="background-image: url('<?= base_url('template/asset/img/banner.png') ?>'); background-size: cover; background-position: center;">
        <div class="container">
            <h1 class="fw-bold mb-4">BOOKING LAPANGAN ONLINE TERBAIK</h1>
        </div>
    </div>

    <!-- Content -->
    <div class="container my-5">
        <h1 class="text-center">Data Lapangan</h1>

        <!-- Tampilan Kartu -->
        <div class="container mt-4">
            <div class="row">
                <?php if (!empty($lapangan)): ?>
                    <?php foreach ($lapangan as $item): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <a href="<?= site_url('penyewa/detail/' . $item['id_lapangan']) ?>">
                                    <img src="<?= base_url('uploads/' . $item['foto']) ?>" class="card-img-top" alt="Foto Lapangan" style="object-fit: cover; height: 200px;">
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title"><?= esc($item['nama_lapangan']) ?></h5>
                                    <p class="card-text"><?= esc($item['deskripsi']) ?></p>
                                    <p class="card-text">
                                        <strong>Harga Per Jam:</strong> Rp <?= number_format(esc($item['harga_per_jam']), 0, ',', '.') ?>
                                    </p>
                                </div>
                                <div class="card-footer text-center">
                                    <a href="<?= site_url('penyewa/booking_lapangan/' . $item['id_lapangan']) ?>" class="btn btn-primary btn-sm">Booking</a>
                                    <!-- Tombol Jadwal -->
                                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#jadwalModal<?= $item['id_lapangan'] ?>">
                                        Jadwal
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Modal Jadwal -->
                        <div class="modal fade" id="jadwalModal<?= $item['id_lapangan'] ?>" tabindex="-1" aria-labelledby="jadwalModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="jadwalModalLabel">Jadwal Lapangan <?= esc($item['nama_lapangan']) ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Tampilkan nama pemesan dalam tabel -->
                                        <?php if (!empty($item['pemesanan'])): ?>
                                            <table class="table table-bordered">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th>Nama Pemesan</th>
                                                        <th>Tanggal</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($item['pemesanan'] as $pemesanan): ?>
                                                        <tr>
                                                            <td><?= esc($pemesanan['nama_pemesan']) ?></td>
                                                            <td><?= esc($pemesanan['tanggal']) ?></td>

                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        <?php else: ?>
                                            <p class="text-muted">Belum ada yang booking untuk lapangan ini.</p>
                                        <?php endif; ?>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <p>Tidak ada data lapangan.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <footer class="footer bg-white py-5">
            <div class="container">
                <div class="row">
                    <!-- Logo dan Info Perusahaan -->
                    <div class="col-md-3">
                        <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" class="mb-2" width="100">
                        <h6 class="fw-bold">Fajar Zaelani</h6>
                        <p class="text-muted small">Jl. Wahid Hasyim No. 10D<br>Jakarta Pusat 10340<br>DKI Jakarta, Indonesia</p>
                        <p class="text-muted small"><i class="fas fa-phone-alt"></i> +62878-8552-3838</p>
                        <div class="social-icons">
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-facebook"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-tiktok"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>

                    <!-- Navigasi Footer -->
                    <div class="col-md-2">
                        <h6 class="fw-bold">Perusahaan</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Tentang</a></li>
                            <li><a href="#" class="text-muted">Kebijakan & Privasi</a></li>
                            <li><a href="#" class="text-muted">Syarat dan Ketentuan</a></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <h6 class="fw-bold">Ekosistem</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Sparring</a></li>
                            <li><a href="#" class="text-muted">Main Bareng</a></li>
                            <li><a href="#" class="text-muted">Direktori Tim</a></li>
                            <li><a href="#" class="text-muted">Direktori Lapangan</a></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <h6 class="fw-bold">Hubungi Kami</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Kontak</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h6 class="fw-bold">Unduh Aplikasi</h6>
                        <i class="fab fa-apple fa-2x text-muted"></i>
                    </div>
                </div>

                <hr>

                <div class="text-center text-muted small py-3">
                    &copy; 2025 Fajar Zaelani
                </div>
            </div>
        </footer>

        <!-- Tambahkan FontAwesome untuk ikon -->
        <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>