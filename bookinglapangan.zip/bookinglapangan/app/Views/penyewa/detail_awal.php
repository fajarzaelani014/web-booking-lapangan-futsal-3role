<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Lapangan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row align-items-center">
            <!-- Gambar Lapangan -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <img src="<?= base_url('uploads/' . $lapangan['foto']) ?>" class="card-img-top img-fluid rounded" alt="Foto Lapangan">
                </div>
            </div>

            <!-- Detail Lapangan -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <h2 class="card-title text-primary fw-bold"><?= esc($lapangan['nama_lapangan']) ?></h2>
                        <hr>

                        <!-- Daftar Fasilitas -->
                        <div class="mt-3">
                            <h5 class="fw-semibold"><i class="fas fa-list me-2"></i>Fasilitas</h5>
                            <ul class="list-unstyled mt-3">
                                <?php if (!empty($lapangan['fasilitas'])): ?>
                                    <?php
                                    // Pecah data fasilitas menjadi array
                                    $fasilitas = explode(',', $lapangan['fasilitas']);
                                    $icons = [
                                        'Cafe & Resto' => 'fas fa-utensils',
                                        'Hot Shower' => 'fas fa-shower',
                                        'Jual Makanan Ringan' => 'fas fa-cookie-bite',
                                        'Jual Minuman' => 'fas fa-coffee',
                                        'Musholla' => 'fas fa-mosque',
                                        'Parkir Mobil' => 'fas fa-car',
                                        'WiFi' => 'fas fa-wifi',
                                        'Kolam Renang' => 'fas fa-swimmer',
                                        'Ruang Pertemuan' => 'fas fa-users',
                                        'Fitness Center' => 'fas fa-dumbbell',
                                        'ATM' => 'fas fa-credit-card',
                                        'Pusat Perbelanjaan' => 'fas fa-shopping-cart',
                                        'Kamar Mandi' => 'fas fa-bath',
                                        'AC' => 'fas fa-snowflake',
                                        'Kantor Pos' => 'fas fa-envelope',
                                        'Transportasi' => 'fas fa-bus',
                                        'Penitipan Barang' => 'fas fa-box',
                                        'Pusat Kesehatan' => 'fas fa-hospital',
                                        'Toko Oleh-Oleh' => 'fas fa-gift',
                                        'Beli Tiket' => 'fas fa-ticket-alt',
                                        'Jasa Pengantaran' => 'fas fa-truck',
                                        'Jasa Pembersih' => 'fas fa-broom',
                                        'Keamanan' => 'fas fa-shield-alt',
                                        'Parkir Sepeda' => 'fas fa-bicycle',
                                        'Pemandu Wisata' => 'fas fa-binoculars',
                                    ];
                                    ?>
                                    <?php foreach ($fasilitas as $f): ?>
                                        <li class="d-flex align-items-center py-2 border-bottom">
                                            <i class="<?= isset($icons[trim($f)]) ? $icons[trim($f)] : 'fas fa-check-circle' ?> text-success me-3"></i>
                                            <span class="fw-medium"><?= esc($f) ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li class="text-muted">Fasilitas tidak tersedia.</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Deskripsi -->
            <p class="card-text mt-4">
                <strong class="text-secondary">Deskripsi:</strong> <?= esc($lapangan['deskripsi']) ?>
            </p>

            <!-- Harga Per Jam -->
            <p class="card-text">
                <strong>Harga Per Jam:</strong> Rp <?= esc($lapangan['harga_per_jam']) ?>
            </p>

            <!-- Tombol Booking -->
            <div class="mt-4">
                <a class="btn btn-primary btn-lg shadow-sm" onclick="showLoginPopup()">
                    Masukan Keranjang
                </a>

            </div>
        </div>
    </div>
    </div>
    </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        function showLoginPopup() {
            Swal.fire({
                title: "Anda Harus Login!",
                text: "Silakan login terlebih dahulu untuk melakukan booking.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Login Sekarang",
                cancelButtonText: "Batal",
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= base_url('auth/login'); ?>";
                }
            });
        }
    </script>
</body>

</html>