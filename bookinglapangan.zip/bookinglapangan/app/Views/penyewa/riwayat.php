<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Penyewaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }

        .card {
            border: none;
            border-radius: 10px;
            transition: transform 0.2s;
            cursor: pointer;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .footer a {
            text-decoration: none;
        }

        .social-icons a {
            margin-right: 10px;
            color: #6c757d;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="https://ligaayo.com/" target="_blank">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>

                <!-- Tombol Profil dengan Dropdown -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> Profil
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/profil') ?>">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/riwayat') ?>">Lihat Riwayat</a></li>
                    </ul>
                </div>

                <a href="<?= site_url('/logout') ?>" class="btn btn-danger ms-2">Logout</a>

            </div>
        </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Riwayat Penyewaan</h2>
        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger text-center" role="alert">
                <?= session()->getFlashdata('error'); ?>
            </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light text-center">
                    <tr>
                        <th>No</th>
                        <th>Lapangan</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($riwayat)) : ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">Belum ada riwayat pemesanan lapangan futsal.</td>
                        </tr>
                    <?php else : ?>
                        <?php $no = 1; ?>
                        <?php foreach ($riwayat as $r) : ?>
                            <tr class="text-center">
                                <td><?= $no++; ?></td>
                                <td><?= $r['nama_lapangan']; ?></td>
                                <td><?= date('d M Y', strtotime($r['tanggal'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modal<?= $r['id_pemesanan']; ?>">
                                        Detail
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal Detail Penyewaan -->
                            <div class="modal fade" id="modal<?= $r['id_pemesanan']; ?>" tabindex="-1" aria-labelledby="modalLabel<?= $r['id_pemesanan']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="modalLabel<?= $r['id_pemesanan']; ?>">Detail Penyewaan</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>Nama Lapangan:</strong> <?= $r['nama_lapangan']; ?></p>
                                            <p><strong>Tanggal:</strong> <?= date('d M Y', strtotime($r['tanggal'])); ?></p>
                                            <p><strong>Nama Pemesan:</strong> <?= isset($r['nama_pemesan']) ? $r['nama_pemesan'] : 'Tidak tersedia'; ?></p>
                                            <p><strong>Harga per Jam:</strong> Rp<?= number_format($r['harga_per_jam'], 0, ',', '.'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <footer class="footer bg-gray py-5">
            <div class="container">
                <div class="row">
                    <!-- Logo dan Info Perusahaan -->
                    <div class="col-md-3">
                        <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" class="mb-2" width="100">
                        <h6 class="fw-bold">Fajar Zaelani</h6>
                        <p class="text-muted small">Jl. Wahid Hasyim No. 10D<br>Jakarta Pusat 10340<br>DKI Jakarta, Indonesia</p>
                        <p class="text-muted small"><i class="fas fa-phone-alt"></i> +62878-8552-3838</p>
                        <div class="social-icons">
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-facebook"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-tiktok"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>

                    <!-- Navigasi Footer -->
                    <div class="col-md-2">
                        <h6 class="fw-bold">Perusahaan</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Tentang</a></li>
                            <li><a href="#" class="text-muted">Kebijakan & Privasi</a></li>
                            <li><a href="#" class="text-muted">Syarat dan Ketentuan</a></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <h6 class="fw-bold">Ekosistem</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Sparring</a></li>
                            <li><a href="#" class="text-muted">Main Bareng</a></li>
                            <li><a href="#" class="text-muted">Direktori Tim</a></li>
                            <li><a href="#" class="text-muted">Direktori Lapangan</a></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <h6 class="fw-bold">Hubungi Kami</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-muted">Kontak</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h6 class="fw-bold">Unduh Aplikasi</h6>
                        <i class="fab fa-apple fa-2x text-muted"></i>
                    </div>
                </div>

                <hr>

                <div class="text-center text-muted small py-3">
                    &copy; 2025 Fajar Zaelani
                </div>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>