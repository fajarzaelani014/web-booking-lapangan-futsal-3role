<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Booking Lapangan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffebee;
        }

        .card {
            border: 1px solid #d32f2f;
        }

        .card-header {
            background-color: #d32f2f;
            color: white;
        }

        .btn-primary {
            background-color: #b71c1c;
            border-color: #b71c1c;
        }

        .btn-primary:hover {
            background-color: #7f0000;
            border-color: #7f0000;
        }

        .clickable-time {
            cursor: pointer;
            color: #c62828;
            text-decoration: underline;
        }

        .clickable-time:hover {
            color: #b71c1c;
        }

        .tanggal-container {
            display: flex;
            gap: 15px;
            overflow-x: auto;
            padding: 10px;
            white-space: nowrap;
        }

        .tanggal-item {
            text-align: center;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            min-width: 80px;
            transition: all 0.3s;
            background-color: #f0f0f0;
            color: black;
        }

        .tanggal-item.active {
            background-color: #900d23;
            color: white;
            font-weight: bold;
        }

        .tanggal-item span {
            display: block;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="https://ligaayo.com/" target="_blank">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>

                <!-- Tombol Profil dengan Dropdown -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> Profil
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/profil') ?>">Lihat Profil</a></li>
                    </ul>
                </div>

                <div class="d-flex align-items-center">
                    <a href="<?= site_url('/logout') ?>" class="btn btn-danger ms-2">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container text-center">
        <h2 class="mb-4 text-danger">Detail Booking Lapangan</h2>

        <?php if ($lapangan): ?>
            <div class="card shadow-lg">
                <div class="card-header">
                    <h3><?= esc($lapangan['nama_lapangan']) ?></h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID Lapangan:</strong> <?= esc($lapangan['id_lapangan']) ?></p>
                            <p><strong>Deskripsi:</strong> <?= esc($lapangan['deskripsi']) ?></p>
                            <p><strong>Harga:</strong> Rp <?= number_format(esc($lapangan['harga_per_jam']), 0, ',', '.') ?> / Jam</p>
                            <p><strong>Fasilitas:</strong></p>
                            <ul class="list-group">
                                <?php
                                $fasilitas = explode(',', $lapangan['fasilitas']);
                                $icons = [
                                    'Cafe & Resto' => 'fas fa-utensils',
                                    'Hot Shower' => 'fas fa-shower',
                                    'Jual Makanan Ringan' => 'fas fa-cookie-bite',
                                    'Jual Minuman' => 'fas fa-coffee',
                                    'Musholla' => 'fas fa-mosque',
                                    'Parkir Mobil' => 'fas fa-car',
                                    'WiFi' => 'fas fa-wifi',
                                    'Kolam Renang' => 'fas fa-swimmer',
                                    'Ruang Pertemuan' => 'fas fa-users',
                                    'Fitness Center' => 'fas fa-dumbbell',
                                    'ATM' => 'fas fa-credit-card',
                                    'Pusat Perbelanjaan' => 'fas fa-shopping-cart',
                                    'Kamar Mandi' => 'fas fa-bath',
                                    'AC' => 'fas fa-snowflake',
                                    'Keamanan' => 'fas fa-shield-alt',
                                    'Parkir Sepeda' => 'fas fa-bicycle',
                                ];
                                ?>
                                <?php foreach ($fasilitas as $fasilitas_item): ?>
                                    <li class="list-group-item">
                                        <i class="<?= $icons[trim($fasilitas_item)] ?? 'fas fa-cogs' ?> text-danger"></i> <?= esc(trim($fasilitas_item)) ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Foto Lapangan:</strong></p>
                            <img src="<?= base_url('uploads/' . $lapangan['foto']) ?>" class="img-fluid rounded" alt="Foto Lapangan">
                        </div>
                    </div>

                    <div class="container mt-3">
                        <div class="tanggal-container">
                            <?php
                            $hariIni = date('Y-m-d'); // Ambil tanggal hari ini
                            for ($i = 0; $i < 7; $i++) :
                                $tanggal = date('Y-m-d', strtotime("+$i days"));
                                $namaHari = date('D', strtotime($tanggal)); // Nama hari singkat (Min, Sen, Sel, dst.)
                                $tanggalTampil = date('d M', strtotime($tanggal));
                                $active = ($tanggal == $hariIni) ? "active" : ""; // Set hari ini sebagai aktif
                            ?>
                                <div class="tanggal-item <?= $active ?>" onclick="pilihTanggal(this, '<?= $tanggal ?>')">
                                    <span><?= $namaHari ?></span>
                                    <strong><?= $tanggalTampil ?></strong>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <h5 class="mt-4 text-danger">Jadwal Tersedia:</h5>
                    <div class="row" id="jadwalContainer">

                        <?php
                        // Ambil tanggal yang dipilih atau default ke hari ini
                        $tanggal_dipilih = $_GET['tanggal'] ?? date('Y-m-d');
                        $jadwal_dipilih = [];

                        // Filter jadwal yang sesuai tanggal yang dipilih (harusnya kolom tanggal tersedia di tabel jadwal)
                        foreach ($jadwal as $j) {
                            if ($j['tanggal'] == $tanggal_dipilih) {
                                $jadwal_dipilih[] = $j;
                            }
                        }
                        ?>

                        <?php if (!empty($jadwal_dipilih)): ?>
                            <?php foreach ($jadwal_dipilih as $item): ?>
                                <div class="col-md-3 mb-3">
                                    <?php
                                    $jadwal_terpakai = false;

                                    // Cek apakah jadwal sudah dipesan di tanggal tersebut
                                    foreach ($pemesanan as $p) {
                                        if ($p['id_jadwal'] == $item['id_jadwal'] && $p['tanggal'] == $tanggal_dipilih) {
                                            $jadwal_terpakai = true;
                                            break;
                                        }
                                    }

                                    $status = $jadwal_terpakai ? 'booked' : 'available';
                                    ?>

                                    <div class="card shadow-sm text-center <?= ($status == 'booked') ? 'bg-light' : 'bg-white'; ?>">
                                        <div class="card-body">
                                            <p>
                                                <strong>
                                                    <?= date('H:i', strtotime($item['jam_mulai'])) ?> - <?= date('H:i', strtotime($item['jam_selesai'])) ?>
                                                </strong>
                                            </p>
                                            <?php if ($status == 'booked'): ?>
                                                <span class="badge bg-danger">Booked</span>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-primary"
                                                    onclick="cekJadwal(<?= esc($item['id_jadwal']) ?>, '<?= esc($item['jam_mulai']) ?>', '<?= esc($item['jam_selesai']) ?>', '<?= esc($tanggal_dipilih) ?>')">
                                                    Pilih
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12 text-center">
                                <p class="text-muted">Tidak ada jadwal tersedia untuk tanggal <strong><?= esc($tanggal_dipilih) ?></strong>.</p>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="text-center mt-3">
                        <a href="<?= base_url('penyewa') ?>" class="btn btn-primary">Kembali</a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center">
                <p class="mt-4 text-danger">Lapangan tidak ditemukan.</p>
                <a href="<?= base_url('penyewa') ?>" class="btn btn-primary">Kembali</a>
            </div>
        <?php endif; ?>
    </div>

    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
    <script>
        function cekJadwal(idJadwal, jamMulai, jamSelesai, tanggal) {
            let pemesanan = <?= json_encode($pemesanan) ?>; // Data pemesanan dari backend
            let jadwalDipakai = pemesanan.some(p => p.id_jadwal == idJadwal && p.tanggal == "<?= date('Y-m-d') ?>");
            window.location.href = "<?= base_url('pembayaran/halaman_checkout') ?>?id_jadwal=" + idJadwal + "&jam_mulai=" + jamMulai + "&jam_selesai=" + jamSelesai + "&tanggal=" + tanggal;


        }

        function pilihTanggal(element, tanggal) {
            if (element.classList.contains("disabled")) return;

            document.querySelectorAll('.tanggal-item').forEach(item => item.classList.remove('active'));
            element.classList.add('active');
        }

        function pilihTanggal(element, tanggal) {
            document.querySelectorAll('.tanggal-item').forEach(el => el.classList.remove('active'));
            element.classList.add('active');

            // Update tampilan jadwal berdasarkan tanggal yang dipilih
            fetch(`?tanggal=${tanggal}`)
                .then(response => response.text())
                .then(html => {
                    document.getElementById('jadwalContainer').innerHTML = new DOMParser().parseFromString(html, 'text/html').querySelector('#jadwalContainer').innerHTML;
                });
        }
    </script>
    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>