<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Lapangan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="height: 30px;" class="me-2">
                <span class="fw-bold text-danger">FAJAR</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="<?= site_url('penyewa/home_penyewa') ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('penyewa/halaman_penyewa') ?>" class="nav-link text-dark">Lapangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Liga AYO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-muted" href="#">Blog</a>
                    </li>
                </ul>

                <!-- Tombol Profil dengan Dropdown -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> Profil
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="<?= site_url('penyewa/profil') ?>">Lihat Profil</a></li>
                    </ul>
                </div>

                <div class="d-flex align-items-center">
                    <a href="#" id="cartLink" class="text-dark me-3 position-relative" data-bs-toggle="offcanvas" data-bs-target="#cartModal" aria-controls="cartModal">
                        <i class="bi bi-cart fs-5"></i>
                        <span id="cartBadge" class="badge bg-danger text-white position-absolute top-0 start-100 translate-middle p-1">0</span>
                    </a>
                    <a href="<?= site_url('/logout') ?>" class="btn btn-danger ms-2">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Modal Keranjang -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="cartModal" aria-labelledby="cartModalLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="cartModalLabel">Keranjang</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div id="cartItems">
                <p class="text-muted">Keranjang kosong</p>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="successToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true">
            <div class="d-flex">
                <div class="toast-body">
                    Berhasil Menghapus Lapangan
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>


    <div class="container mt-5">
        <div class="row align-items-center">
            <!-- Gambar Lapangan -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <img src="<?= base_url('uploads/' . $lapangan['foto']) ?>" class="card-img-top img-fluid rounded" alt="Foto Lapangan">
                </div>
            </div>

            <!-- Detail Lapangan -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <h2 class="card-title text-primary fw-bold"><?= esc($lapangan['nama_lapangan']) ?></h2>
                        <hr>

                        <!-- Daftar Fasilitas -->
                        <div class="mt-3">
                            <h5 class="fw-semibold"><i class="fas fa-list me-2"></i>Fasilitas</h5>
                            <ul class="list-unstyled mt-3">
                                <?php if (!empty($lapangan['fasilitas'])): ?>
                                    <?php
                                    // Pecah data fasilitas menjadi array
                                    $fasilitas = explode(',', $lapangan['fasilitas']);
                                    $icons = [
                                        'Cafe & Resto' => 'fas fa-utensils',
                                        'Hot Shower' => 'fas fa-shower',
                                        'Jual Makanan Ringan' => 'fas fa-cookie-bite',
                                        'Jual Minuman' => 'fas fa-coffee',
                                        'Musholla' => 'fas fa-mosque',
                                        'Parkir Mobil' => 'fas fa-car',
                                        'WiFi' => 'fas fa-wifi',
                                        'Kolam Renang' => 'fas fa-swimmer',
                                        'Ruang Pertemuan' => 'fas fa-users',
                                        'Fitness Center' => 'fas fa-dumbbell',
                                        'ATM' => 'fas fa-credit-card',
                                        'Pusat Perbelanjaan' => 'fas fa-shopping-cart',
                                        'Kamar Mandi' => 'fas fa-bath',
                                        'AC' => 'fas fa-snowflake',
                                        'Kantor Pos' => 'fas fa-envelope',
                                        'Transportasi' => 'fas fa-bus',
                                        'Penitipan Barang' => 'fas fa-box',
                                        'Pusat Kesehatan' => 'fas fa-hospital',
                                        'Toko Oleh-Oleh' => 'fas fa-gift',
                                        'Beli Tiket' => 'fas fa-ticket-alt',
                                        'Jasa Pengantaran' => 'fas fa-truck',
                                        'Jasa Pembersih' => 'fas fa-broom',
                                        'Keamanan' => 'fas fa-shield-alt',
                                        'Parkir Sepeda' => 'fas fa-bicycle',
                                        'Pemandu Wisata' => 'fas fa-binoculars',
                                    ];
                                    ?>
                                    <?php foreach ($fasilitas as $f): ?>
                                        <li class="d-flex align-items-center py-2 border-bottom">
                                            <i class="<?= isset($icons[trim($f)]) ? $icons[trim($f)] : 'fas fa-check-circle' ?> text-success me-3"></i>
                                            <span class="fw-medium"><?= esc($f) ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li class="text-muted">Fasilitas tidak tersedia.</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Deskripsi -->
            <p class="card-text mt-4">
                <strong class="text-secondary">Deskripsi:</strong> <?= esc($lapangan['deskripsi']) ?>
            </p>

            <!-- Harga Per Jam -->
            <p class="card-text">
                <strong>Harga Per Jam:</strong> Rp <?= esc($lapangan['harga_per_jam']) ?>
            </p>

            <!-- Tombol Booking -->
            <div class="mt-4">
                <a href="#" class="btn btn-primary btn-lg shadow-sm" data-id="<?= $lapangan['id_lapangan'] ?>" data-name="<?= esc($lapangan['nama_lapangan']) ?>">Masukan Keranjang</a>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const cartBadge = document.getElementById("cartBadge");
        const cartItems = document.getElementById("cartItems");
        const bookingButtons = document.querySelectorAll(".btn-primary");
        let cart = JSON.parse(localStorage.getItem("cart")) || []; // Load data keranjang dari localStorage

        // Update Badge dan Keranjang
        function updateCartUI() {
            // Update jumlah badge
            cartBadge.textContent = cart.length;

            // Update isi keranjang
            if (cart.length > 0) {
                cartItems.innerHTML = "";
                cart.forEach((item, index) => {
                    const itemDiv = document.createElement("div");
                    itemDiv.classList.add("d-flex", "justify-content-between", "align-items-center", "mb-2");
                    itemDiv.innerHTML = `
                    <a href="<?= base_url('penyewa/booking_lapangan/' . $lapangan['id_lapangan']); ?>" style="color: inherit; text-decoration: none;"><?= $lapangan['nama_lapangan']; ?></a>
                    <i class="fas fa-trash text-danger btn-remove" style="cursor:pointer;" data-index="${index}"></i>
                `;
                    cartItems.appendChild(itemDiv);
                });

                // Tombol hapus item
                cartItems.querySelectorAll(".btn-remove").forEach((btn) =>
                    btn.addEventListener("click", function() {
                        const index = this.getAttribute("data-index");
                        cart.splice(index, 1); // Hapus item dari array
                        localStorage.setItem("cart", JSON.stringify(cart)); // Update localStorage
                        updateCartUI(); // Refresh UI

                        // Tampilkan toast notification
                        const toast = new bootstrap.Toast(document.getElementById('successToast'));
                        toast.show(); // Tampilkan pemberitahuan
                    })
                );
            } else {
                cartItems.innerHTML = "<p class='text-muted'>Keranjang kosong</p>";
            }
        }

        // Tambahkan Lapangan ke Keranjang
        bookingButtons.forEach((button) => {
            button.addEventListener("click", function(e) {
                e.preventDefault();
                const lapanganId = this.getAttribute("data-id");
                const lapanganName = this.getAttribute("data-name");

                // Tambah ke keranjang jika belum ada
                if (!cart.some((item) => item.id === lapanganId)) {
                    cart.push({
                        id: lapanganId,
                        name: lapanganName
                    });
                    localStorage.setItem("cart", JSON.stringify(cart)); // Simpan ke localStorage
                    updateCartUI(); // Refresh UI
                    alert("Lapangan berhasil ditambahkan ke keranjang!");
                } else {
                    alert("Lapangan ini sudah ada di keranjang!");
                }
            });
        });

        // Inisialisasi UI
        updateCartUI();
    });
</script>


</html>