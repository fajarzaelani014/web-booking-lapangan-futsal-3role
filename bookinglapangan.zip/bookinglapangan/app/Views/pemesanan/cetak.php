<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Pemesanan</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.3/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: rgb(255, 255, 255);
            color: black;
            font-weight: bold;
        }

        .signature {
            margin-top: 50px;
            text-align: right;
            font-size: 18px;
            font-weight: bold;
        }

        .btn-group {
            margin-top: 20px;
        }

        .btn-group button {
            padding: 10px 15px;
            margin: 5px;
            cursor: pointer;
            border: none;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .btn-group img {
            width: 20px;
            height: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Detail Pemesanan</h2>
        <table id="pemesananTable">
            <tr>
                <th>ID Pemesanan</th>
                <td><?= esc($pemesanan['id_pemesanan']) ?></td>
            </tr>
            <tr>
                <th>Nama Lapangan</th>
                <td><?= esc($pemesanan['nama_lapangan']) ?></td>
            </tr>
            <tr>
                <th>Harga per Jam</th>
                <td>Rp <?= number_format((float)$pemesanan['harga_per_jam'], 0, ',', '.') ?></td>
            </tr>
            <tr>
                <th>ID Jadwal</th>
                <td><?= esc($pemesanan['id_jadwal']) ?></td>
            </tr>
            <tr>
                <th>Nama Pemesan</th>
                <td><?= esc($pemesanan['nama_pemesan']) ?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td><?= esc($pemesanan['tanggal']) ?></td>
            </tr>
            <tr>
                <th>Jam Mulai</th>
                <td><?= esc($pemesanan['jammulaijadwal']) ?></td>
            </tr>
            <tr>
                <th>Jam Selesai</th>
                <td><?= esc($pemesanan['jamselesaijadwal']) ?></td>
            </tr>
        </table>

        <div class="signature">
            <p>Fajar Zaelani</p>
        </div>

        <div class="btn-group">
            <button onclick="exportToExcel()">
                <img src="https://img.icons8.com/color/48/000000/ms-excel.png" alt="Excel"> Download Excel
            </button>
            <button onclick="exportToPDF()">
                <img src="https://img.icons8.com/color/48/000000/pdf.png" alt="PDF"> Download PDF
            </button>
            <button onclick="window.print()">
                Cetak
            </button>
        </div>
    </div>

    <script>
        function exportToExcel() {
            let table = document.getElementById("pemesananTable");
            let wb = XLSX.utils.book_new();
            let ws = XLSX.utils.table_to_sheet(table);

            // Set proper column widths
            ws['!cols'] = [{
                    wch: 20
                }, // Kolom pertama
                {
                    wch: 30
                } // Kolom kedua
            ];

            // Format header
            let range = XLSX.utils.decode_range(ws['!ref']);
            for (let C = range.s.c; C <= range.e.c; C++) {
                let cell = ws[XLSX.utils.encode_cell({
                    r: 0,
                    c: C
                })];
                if (cell) {
                    cell.s = {
                        font: {
                            bold: true
                        },
                        fill: {
                            fgColor: {
                                rgb: "4CAF50"
                            }
                        },
                        alignment: {
                            horizontal: "center"
                        }
                    };
                }
            }

            XLSX.utils.book_append_sheet(wb, ws, "Detail Pemesanan");
            XLSX.writeFile(wb, "Pemesanan.xlsx");
        }

        function exportToPDF() {
            const {
                jsPDF
            } = window.jspdf;
            let doc = new jsPDF();
            doc.text("Detail Pemesanan", 10, 10);
            let rows = [];
            let table = document.getElementById("pemesananTable");
            for (let i = 0; i < table.rows.length; i++) {
                let row = [];
                for (let j = 0; j < table.rows[i].cells.length; j++) {
                    row.push(table.rows[i].cells[j].innerText);
                }
                rows.push(row);
            }
            doc.autoTable({
                head: [
                    ['Kolom', 'Data']
                ],
                body: rows
            });
            doc.save("Pemesanan.pdf");
        }
    </script>
</body>

</html>