<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Pemesanan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            background: url('https://www.example.com/path-to-your-image.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: rgba(31, 34, 53, 0.9);
            /* Semi-transparent dark background */
            color: white;
            position: fixed;
            padding-top: 20px;
            overflow-y: auto;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            font-size: 16px;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar .active {
            background-color: #6468a3;
            border-radius: 8px;
        }

        .sidebar i {
            margin-right: 10px;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            background-color: rgba(255, 255, 255, 0.8);
            /* Semi-transparent background */
            border-radius: 10px;
        }

        .section-title {
            font-size: 14px;
            text-transform: uppercase;
            padding: 10px 20px;
            color: #8b8fa5;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .content {
                margin-left: 200px;
                width: calc(100% - 200px);
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                position: absolute;
                width: 100%;
                height: auto;
                padding-bottom: 10px;
            }

            .content {
                margin-left: 0;
                width: 100%;
            }
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
            overflow-y: auto;
            /* Enable scrolling when content exceeds the height */
        }

        /* Styling for each sidebar item */
        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
        }

        /* Section title for better separation */
        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        /* Optional: Customize sidebar title (optional) */
        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Styling for the scrollable content */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        /* Adjustments for the layout */
        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->
        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('admin/halaman_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('lapangan/data_lapangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>
        <a href="<?= site_url('jadwal/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-calendar-check me-2"></i> Jadwal
        </a>
        <a href="<?= site_url('liga/liga_ayo') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-trophy me-2"></i> Liga AYO
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Manajemen Pengguna</div>
        <a href="<?= site_url('user/index') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-people me-2"></i> Daftar Pengguna
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pemesanan/halaman_pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('laporan/pemesanan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('admin/profil_admin') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-person-circle me-2"></i> Profil Admin
        </a>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <div class="content">
        <h1 class="text-center text-primary fw-bold">Data Pemesanan</h1>

        <!-- Card untuk Form Filter -->
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <h5 class="card-title fw-bold">Filter Data</h5>
                <form method="GET" action="<?= base_url('pemesanan/halaman_pemesanan') ?>">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label for="tanggal" class="form-label fw-bold">Tanggal</label>
                            <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?= esc($_GET['tanggal'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="bulan" class="form-label fw-bold">Bulan</label>
                            <select name="bulan" id="bulan" class="form-select">
                                <option value="">Semua Bulan</option>
                                <?php for ($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?= $i ?>" <?= (isset($_GET['bulan']) && $_GET['bulan'] == $i) ? 'selected' : '' ?>>
                                        <?= date('F', mktime(0, 0, 0, $i, 10)) ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="tahun" class="form-label fw-bold">Tahun</label>
                            <select name="tahun" id="tahun" class="form-select">
                                <option value="">Semua Tahun</option>
                                <?php
                                $tahun_sekarang = date('Y');
                                for ($i = $tahun_sekarang; $i >= 2000; $i--): ?>
                                    <option value="<?= $i ?>" <?= (isset($_GET['tahun']) && $_GET['tahun'] == $i) ? 'selected' : '' ?>>
                                        <?= $i ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="id_lapangan" class="form-label fw-bold">Nama Lapangan</label>
                            <select name="id_lapangan" id="id_lapangan" class="form-select">
                                <option value="">Semua Lapangan</option>
                                <?php foreach ($lapangan as $l): ?>
                                    <option value="<?= $l['id_lapangan'] ?>" <?= (isset($_GET['id_lapangan']) && $_GET['id_lapangan'] == $l['id_lapangan']) ? 'selected' : '' ?>>
                                        <?= $l['nama_lapangan'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-3 align-items-center">
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary w-100">
                                🔍 Filter
                            </button>
                        </div>
                        <div class="col-md-3">
                            <label for="per_page" class="form-label fw-bold">Pilih Baris:</label>
                            <select name="per_page" id="per_page" class="form-select" onchange="this.form.submit()">
                                <option value="all" <?= ($perPage == 'all') ? 'selected' : '' ?>>Semua Baris</option>
                                <option value="3" <?= ($perPage == 3) ? 'selected' : '' ?>>3</option>
                                <option value="5" <?= ($perPage == 5) ? 'selected' : '' ?>>5</option>
                                <option value="10" <?= ($perPage == 10) ? 'selected' : '' ?>>10</option>
                                <option value="20" <?= ($perPage == 20) ? 'selected' : '' ?>>20</option>
                            </select>
                        </div>
                    </div>
                </form>
                <div class="col-md-3">
                    <button type="button" class="btn btn-success w-100" onclick="printTable()">
                        🖨️ Cetak
                    </button>
                </div>
            </div>
        </div>

        <!-- Card untuk Tabel -->
        <div class="card shadow-sm" id="cetak-area">
            <div class="card-body">
                <h5 class="card-title fw-bold">Daftar Pemesanan</h5>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th>
                                <th>Nama Lapangan</th>
                                <th>Harga per Jam</th>
                                <th>Id User</th>
                                <th>Nama Pemesan</th>
                                <th>Tanggal</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="text-center align-middle">
                            <?php if (!empty($pemesanan)): ?>
                                <?php
                                // Ambil halaman sekarang dari pagination group 'pemesanan'
                                $currentPage = $pager->getCurrentPage('pemesanan');
                                $perPage = $pager->getPerPage('pemesanan') ?? 10; // fallback ke 10 jika tidak tersedia
                                $no = 1 + ($perPage * ($currentPage - 1));
                                ?>
                                <?php foreach ($pemesanan as $item): ?>
                                    <?php
                                    $waktu_sekarang = date('Y-m-d H:i:s'); // Waktu sekarang
                                    $waktu_selesai = $item['tanggal'] . ' ' . $item['jamselesaijadwal'];

                                    // Cek apakah jadwal sudah terlewat
                                    $jadwal_terlewat = strtotime($waktu_selesai) < strtotime($waktu_sekarang);
                                    ?>
                                    <tr class="table-light">
                                        <td class="fw-semibold"><?= $no++ ?></td>
                                        <td><?= esc($item['nama_lapangan']) ?></td>
                                        <td class="text-success fw-bold">Rp <?= number_format((float) $item['harga_per_jam'], 0, ',', '.') ?></td>
                                        <td><?= esc($item['id_user']) ?></td>
                                        <td><?= esc($item['nama_pemesan']) ?></td>
                                        <td><?= esc($item['tanggal']) ?></td>
                                        <td><?= esc($item['jammulaijadwal']) ?></td>
                                        <td><?= esc($item['jamselesaijadwal']) ?></td>
                                        <td>
                                            <?php if ($jadwal_terlewat): ?>
                                                <span class="badge bg-danger">Jadwal sudah terlewat</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Masih berlaku</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="cetakPemesanan('<?= esc($item['id_pemesanan']) ?>')">
                                                <i class="bi bi-printer"></i> Cetak
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?= esc($item['id_pemesanan']) ?>)">
                                                <i class="bi bi-trash3"></i> Hapus
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center text-muted">Tidak ada data pemesanan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Pagination -->
        <?php if (isset($pager) && !empty($pager)) : ?>
            <div class="d-flex justify-content-center mt-4">
                <?= $pager->links('pemesanan', 'bootstrap_custom') ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        function cetakPemesanan(id) {
            var url = "<?= site_url('pemesanan/cetak/') ?>" + id;
            var win = window.open(url, '_blank');
            win.focus();
        }

        function confirmDelete(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data pemesanan yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                background: '#fefefe', // Background pop-up lebih cerah
                backdrop: `
            rgba(0, 0, 0, 0.4)
            url("https://www.example.com/your-custom-image.gif") left top no-repeat
        `, // Menambahkan latar belakang animasi/gambar
                customClass: {
                    title: 'text-warning font-weight-bold', // Desain untuk title
                    content: 'font-italic text-muted', // Styling untuk text content
                    cancelButton: 'btn btn-secondary btn-lg', // Desain tombol batal
                    confirmButton: 'btn btn-danger btn-lg' // Desain tombol konfirmasi
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Proses penghapusan data
                    // Ganti dengan kode penghapusan data yang sesuai dengan aplikasi Anda

                    // Redirect setelah penghapusan
                    window.location.href = "<?= site_url('pemesanan/delete/') ?>" + id;

                    // Notifikasi setelah berhasil dihapus
                    Swal.fire({
                        title: 'Sukses!',
                        text: 'Pemesanan telah berhasil dihapus.',
                        icon: 'success',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK',
                        background: '#e0f7fa', // Latar belakang notifikasi lebih cerah
                        customClass: {
                            title: 'text-success font-weight-bold', // Desain untuk title
                            content: 'font-italic text-dark', // Styling untuk text content
                            confirmButton: 'btn btn-primary btn-lg' // Desain tombol konfirmasi
                        }
                    });
                }
            });
        }

        function printTable() {
            const areaCetak = document.getElementById('cetak-area').innerHTML;
            const original = document.body.innerHTML;

            document.body.innerHTML = areaCetak;
            window.print();
            document.body.innerHTML = original;
        }
    </script>
</body>

</html>