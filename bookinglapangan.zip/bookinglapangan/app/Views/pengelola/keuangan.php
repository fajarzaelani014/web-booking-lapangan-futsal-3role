<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Keuangan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #1f2235;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
            overflow-y: auto;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            font-size: 16px;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar .active {
            background-color: #6468a3;
            border-radius: 8px;
        }

        .sidebar i {
            margin-right: 10px;
        }

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo img {
            width: 80px;
            height: auto;
            border-radius: 10px;
        }

        .sidebar .logo h4 {
            font-size: 1.5rem;
            margin-top: 10px;
            color: #fff;
        }

        /* Styling for each sidebar item */
        .sidebar-item {
            display: block;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .sidebar-item:hover {
            background-color: #007bff;
            padding-left: 20px;
        }

        /* Section title for better separation */
        .section-title {
            font-weight: bold;
            font-size: 0.9rem;
            color: #007bff;
            text-transform: uppercase;
            padding: 10px 20px;
        }

        /* Optional: Customize sidebar title (optional) */
        .sidebar .text-center h4 {
            font-size: 1.5rem;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Styling for the scrollable content */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background-color: #343a40;
        }

        /* Adjustments for the layout */
        .sidebar-item+.sidebar-item {
            margin-top: 5px;
        }

        /* Konten utama */
        .content {
            margin-left: 250px;
            padding: 40px;
            width: calc(100% - 250px);
        }

        .table-responsive {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .welcome-section {
            background: linear-gradient(135deg, #1f2235, #6468a3);
            padding: 40px;
            border-radius: 15px;
            color: white;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            animation: fadeIn 1.5s ease-in-out;
        }

        .welcome-section h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
            animation: slideIn 1s ease-in-out;
        }

        .welcome-section p {
            font-size: 1.2rem;
            animation: slideIn 1.2s ease-in-out;
        }

        /* Animasi */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* Card styling */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .card-text {
            font-size: 1rem;
            color: #666;
        }

        .btn-primary {
            background-color: #1f2235;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #6468a3;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white p-3" style="width: 250px; height: 100vh; position: fixed;">
        <div class="d-flex justify-content-center mb-4">
            <img src="<?= base_url() ?>template/asset/img/logof.jpg" alt="Logo" style="width: 80px; height: auto; border-radius: 10px;">
        </div>
        <div class="text-center mb-4">
            <h4 class="fw-bold text-light">FAJAR</h4>
        </div>

        <!-- Dashboard -->
        <div class="section-title text-uppercase text-light mt-4 mb-2">Kelola</div>
        <a href="<?= site_url('pengelola/home_pengelola') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-house-door me-2"></i> Home
        </a>
        <a href="<?= site_url('pengelola/halaman_pengelola') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-geo-alt me-2"></i> Lapangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Laporan & Rekap</div>
        <a href="<?= site_url('pengelola/laporan_pengelola') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-file-earmark-text me-2"></i> Laporan Pemesanan
        </a>
        <a href="<?= site_url('pengelola/keuangan') ?>" class="sidebar-item text-white d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-cash-stack me-2"></i> Laporan Keuangan
        </a>

        <div class="section-title text-uppercase text-light mt-4 mb-2">Pengaturan</div>
        <a href="<?= site_url('/logout') ?>" class="sidebar-item text-danger d-flex align-items-center py-2 px-3 rounded mb-2">
            <i class="bi bi-box-arrow-right me-2"></i> Logout
        </a>
    </div>

    <!-- Konten Utama -->
    <div class="content mt-4">
        <div class="card p-4">
            <h2 class="text-center mb-4"><i class="fas fa-money-bill-wave"></i> Data Keuangan</h2>

            <!-- Form Filter -->
            <form method="GET" action="">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="tanggal" class="form-label">Pilih Tanggal</label>
                        <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $_GET['tanggal'] ?? '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="bulan" class="form-label">Pilih Bulan</label>
                        <select class="form-control" name="bulan" id="bulan">
                            <option value="">Semua</option>
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= (isset($_GET['bulan']) && $_GET['bulan'] == $i) ? 'selected' : '' ?>>
                                    <?= date('F', mktime(0, 0, 0, $i, 1)) ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="tahun" class="form-label">Pilih Tahun</label>
                        <select class="form-control" name="tahun" id="tahun">
                            <option value="">Semua</option>
                            <?php
                            $tahunSekarang = date('Y');
                            for ($i = $tahunSekarang; $i >= 2020; $i--): ?>
                                <option value="<?= $i ?>" <?= (isset($_GET['tahun']) && $_GET['tahun'] == $i) ? 'selected' : '' ?>>
                                    <?= $i ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                <a href="?" class="btn btn-secondary"><i class="fas fa-sync"></i> Reset</a>
                <button type="button" class="btn btn-success" onclick="printTable()"><i class="fas fa-print"></i> Cetak Laporan</button>
            </form>

            <!-- Card untuk Laporan Keuangan -->
            <div class="card shadow mb-4">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0">Laporan Keuangan</h4>
                </div>
                <div class="card-body">
                    <div id="printArea">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover text-center">
                                <thead class="table-primary">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Lapangan</th>
                                        <th>Tanggal</th>
                                        <th>Harga Per Jam</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totalHarga = 0;
                                    $no = 1;
                                    foreach ($keuangan as $row):
                                        $totalHarga += $row['harga_per_jam'];
                                    ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= esc($row['nama_lapangan']) ?></td>
                                            <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                                            <td><strong>Rp <?= number_format($row['harga_per_jam'], 0, ',', '.') ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="table-secondary">
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Total</strong></td>
                                        <td><strong>Rp <?= number_format($totalHarga, 0, ',', '.') ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- JavaScript untuk Cetak -->
            <script>
                function printTable() {
                    var printContents = document.getElementById('printArea').innerHTML;
                    var originalContents = document.body.innerHTML;

                    document.body.innerHTML = printContents;
                    window.print();
                    document.body.innerHTML = originalContents;
                }
            </script>


            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>