<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liga Ayo - Futsal</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="icon" href="<?= base_url() ?>template/asset/img/logof.jpg" type="image/x-icon">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f8f8;
      color: #333;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #333;
      padding: 15px 30px;
      color: white;
    }

    .navbar .logo h1 {
      font-size: 2.5em;
      color: #ffcb00;
      letter-spacing: 2px;
    }

    .nav-links {
      list-style: none;
      display: flex;
    }

    .nav-links li {
      margin-left: 25px;
    }

    .nav-links a {
      text-decoration: none;
      color: white;
      font-weight: 600;
      font-size: 1.1em;
      transition: color 0.3s ease;
    }

    .nav-links a:hover {
      color: #ffcb00;
    }

    .hero {
      background: url('futsal-field.jpg') no-repeat center center/cover;
      height: 70vh;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      color: white;
      padding: 0 20px;
    }

    .hero-content {
      background-color: rgba(0, 0, 0, 0.5);
      padding: 30px;
      border-radius: 8px;
    }

    .hero h2 {
      font-size: 3.5em;
      margin-bottom: 20px;
    }

    .hero p {
      font-size: 1.3em;
      margin-bottom: 30px;
    }

    .cta-button {
      padding: 15px 35px;
      background-color: #ffcb00;
      border: none;
      font-size: 1.2em;
      cursor: pointer;
      color: black;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }

    .cta-button:hover {
      background-color: #e6b800;
    }

    .about {
      background-color: #2e8b57;
      color: white;
      text-align: center;
      padding: 60px 20px;
    }

    .about h2 {
      font-size: 2.8em;
      margin-bottom: 20px;
    }

    .about p {
      font-size: 1.2em;
      line-height: 1.6;
      max-width: 800px;
      margin: 0 auto;
    }

    .features {
      display: flex;
      justify-content: space-around;
      padding: 60px 20px;
      background-color: #f4f4f4;
    }

    .feature-card {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      width: 30%;
      text-align: center;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .feature-card h3 {
      font-size: 1.8em;
      margin-bottom: 15px;
    }

    .feature-card p {
      font-size: 1.1em;
      color: #555;
    }

    footer {
      background-color: #333;
      color: white;
      text-align: center;
      padding: 20px;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
    <div class="logo">
      <h1>Liga Ayo</h1>
    </div>
    <ul class="nav-links">
      <li><a href="#">Home</a></li>
      <li><a href="#">Pertandingan</a></li>
      <li><a href="#">Tim</a></li>
      <li><a href="#">Pendaftaran</a></li>
    </ul>
  </nav>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-content">
      <h2>Selamat Datang di Liga Ayo Futsal!</h2>
      <p>Daftarkan tim futsal kamu dan buktikan siapa yang terbaik di lapangan!</p>
      <button class="cta-button">Daftar Sekarang</button>
    </div>
  </section>

  <!-- About Section -->
  <section class="about">
    <h2>Tentang Liga Ayo</h2>
    <p>Liga Ayo adalah liga futsal yang mempertemukan berbagai tim dari berbagai daerah untuk bertanding dalam kompetisi futsal yang seru dan menantang. Ayo, buktikan tim futsal terbaikmu di Liga Ayo!</p>
  </section>

  <!-- Features Section -->
  <section class="features">
    <div class="feature-card">
      <h3>Turnamen Berkualitas</h3>
      <p>Setiap pertandingan di Liga Ayo dijalankan dengan profesionalisme tinggi untuk memastikan kompetisi yang adil dan seru.</p>
    </div>
    <div class="feature-card">
      <h3>Tim Terbaik</h3>
      <p>Tim terbaik dari berbagai daerah akan berkompetisi untuk menjadi juara Liga Ayo. Siapa yang akan keluar sebagai juara?</p>
    </div>
    <div class="feature-card">
      <h3>Hadiah Menarik</h3>
      <p>Selain trofi, tim pemenang akan mendapatkan hadiah menarik sebagai apresiasi atas usaha keras mereka.</p>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 Liga Ayo Futsal. All Rights Reserved.</p>
  </footer>
</body>
</html>
