<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    // Menampilkan halaman login
    public function login()
    {
        return view('auth/login');
    }

    public function loginProcess()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if (!$user) {
            // Username salah, kita nggak bisa cek password
            session()->setFlashdata('error', 'Username dan password salah');
            return redirect()->to('/login/admin')->withInput();
        }

        if (!password_verify($password, $user['password'])) {
            // Password salah, tapi username ada
            session()->setFlashdata('error', 'Sandi salah');
            return redirect()->to('/login/admin')->withInput();
        }

        // Login berhasil
        session()->set('user', $user);
        return $this->redirectUser($user['role']);
    }

    // Method untuk redirect pengguna berdasarkan role
    public function redirectUser($role)
    {
        switch ($role) {
            case 'admin':
                return redirect()->to('admin/halaman_admin');
            case 'pengelola':
                return redirect()->to('pengelola/home_pengelola');
            case 'penyewa':
                return redirect()->to('penyewa/halaman_penyewa');
            default:
                // Redirect unauthorized users ke halaman 403
                return redirect()->to('unauthorized');
        }
    }

    // Menampilkan halaman register
    public function register()
    {
        return view('auth/register');
    }

    // Proses register
    public function registerProcess()
    {
        // Ambil data dari form
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $nama = $this->request->getPost('nama');
        $email = $this->request->getPost('email');
        $role = $this->request->getPost('role'); // Misalnya: admin, pengelola, penyewa

        // Hash password sebelum disimpan
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Model untuk pengguna
        $userModel = new UserModel();

        // Simpan data user
        $data = [
            'username' => $username,
            'password' => $hashedPassword,
            'nama' => $nama,
            'email' => $email,
            'role' => $role,
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Insert data ke tabel users
        if ($userModel->insert($data)) {
            session()->setFlashdata('success', 'Pendaftaran berhasil. Silakan login.');
            return redirect()->to('/login/admin'); // Arahkan ke halaman login
        } else {
            session()->setFlashdata('error', 'Pendaftaran gagal. Silakan coba lagi.');
            return redirect()->to('/auth/register'); // Kembali ke halaman register
        }
    }

    public function logout()
    {
        // Your logout logic (e.g., destroying session, redirecting)
        session()->destroy();
        return redirect()->to('auth/login');
    }
}
