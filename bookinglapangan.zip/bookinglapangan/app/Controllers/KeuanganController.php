<?php

namespace App\Controllers;

use App\Models\KeuanganModel;
use App\Models\PemesananModel;
use CodeIgniter\Controller;

class KeuanganController extends Controller
{
    public function index()
    {
        $model = new PemesananModel();

        // Ambil data dari input GET
        $tanggal = $this->request->getGet('tanggal');
        $bulan = $this->request->getGet('bulan');
        $tahun = $this->request->getGet('tahun');

        // Ambil data keuangan berdasarkan filter
        $data['keuangan'] = $model->getKeuangan($tanggal, $bulan, $tahun);

        return view('pengelola/keuangan', $data);
    }
}
