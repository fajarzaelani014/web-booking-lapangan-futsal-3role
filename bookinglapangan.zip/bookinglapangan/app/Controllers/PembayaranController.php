<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class PembayaranController extends Controller
{
    public function checkout()
    {
        // Ambil parameter dari URL
        $id_jadwal = $this->request->getGet('id_jadwal');
        $jam_mulai = $this->request->getGet('jam_mulai');
        $jam_selesai = $this->request->getGet('jam_selesai');

        // Ambil data jadwal berdasarkan id_jadwal
        $jadwalModel = new \App\Models\JadwalModel(); // Pastikan model JadwalModel sudah dibuat
        $jadwal = $jadwalModel->find($id_jadwal);

        // Pastikan jadwal ditemukan
        if (!$jadwal) {
            return redirect()->to('/error-page'); // Ganti dengan halaman error sesuai kebutuhan
        }

        // Ambil data lapangan berdasarkan id_lapangan dari jadwal
        $lapanganModel = new \App\Models\LapanganModel(); // Pastikan model LapanganModel sudah dibuat
        $lapangan = $lapanganModel->find($jadwal['id_lapangan']); // Ambil data lapangan berdasarkan id_lapangan

        // Kirim data ke view
        return view('pembayaran/halaman_checkout', [
            'id_jadwal' => $id_jadwal,
            'jam_mulai' => $jam_mulai,
            'jam_selesai' => $jam_selesai,
            'lapangan' => $lapangan // Pastikan lapangan diteruskan ke view
        ]);
    }

    public function pembayaran()
    {
        // Ambil parameter dari URL untuk pembayaran
        $id_jadwal = $this->request->getGet('id_jadwal');
        $jam_mulai = $this->request->getGet('jam_mulai');
        $jam_selesai = $this->request->getGet('jam_selesai');

        // Memuat model jadwal dan lapangan
        $jadwalModel = new \App\Models\JadwalModel();
        $lapanganModel = new \App\Models\LapanganModel();

        // Ambil data jadwal berdasarkan id_jadwal untuk mendapatkan id_lapangan
        $jadwal = $jadwalModel->find($id_jadwal);

        // Periksa apakah jadwal ditemukan
        if (!$jadwal) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Jadwal tidak ditemukan');
        }

        // Ambil id_lapangan dari data jadwal
        $id_lapangan = $jadwal['id_lapangan'];

        // Ambil data lapangan berdasarkan id_lapangan
        $lapangan = $lapanganModel->find($id_lapangan);


        // dd($id_jadwal);
        // Kirim data ke view
        return view('pembayaran/pembayaran', [
            'id_jadwal' => $id_jadwal,
            'jam_mulai' => $jam_mulai,
            'jam_selesai' => $jam_selesai,
            'lapangan' => $lapangan // Kirim hanya satu lapangan yang sesuai
        ]);
    }
}
