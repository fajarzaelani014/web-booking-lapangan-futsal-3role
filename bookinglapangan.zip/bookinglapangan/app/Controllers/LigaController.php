<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class LigaController extends Controller
{
    public function liga_ayo()
    {
        // Logika untuk halaman liga ayo
        // Kamu bisa menambahkan data atau memanggil model di sini
        return view('liga/liga_ayo'); // Pastikan ada file view liga_ayo.php di folder views/liga
    }
}
