<?php

namespace App\Controllers;

use App\Models\LapanganModel;
use App\Models\JadwalModel;

class JadwalController extends BaseController
{
    protected $jadwalModel;
    protected $lapanganModel;

    public function __construct()
    {
        // Inisialisasi model
        $this->jadwalModel = new JadwalModel();
        $this->lapanganModel = new LapanganModel();
    }

    public function index()
    {
        //
        $lapanganModel = new LapanganModel();

        // Mengambil data jadwal dengan nama lapangan
        $data['jadwal'] = $this->jadwalModel->getJadwalWithLapangan();
        $data['lapangan'] = $lapanganModel->findAll();

        // Mengirimkan data jadwal ke view
        return view('jadwal/index', $data);
    }

    public function edit($id_jadwal)
    {
        // Ambil data jadwal berdasarkan ID
        $jadwal = $this->jadwalModel->find($id_jadwal);

        // Ambil data lapangan
        $lapangan = $this->lapanganModel->findAll();

        // Kirim data ke view
        return view('jadwal/edit', [
            'jadwal' => $jadwal,
            'lapangan' => $lapangan
        ]);
    }

    public function update($id)
    {
        // Validasi input
        $data = [
            'id_lapangan' => $this->request->getVar('id_lapangan'),
            'tanggal'     => $this->request->getVar('tanggal'),
            'jam_mulai'   => $this->request->getVar('jam_mulai'),
            'jam_selesai' => $this->request->getVar('jam_selesai'),
            'status'      => $this->request->getVar('status')
        ];

        // Update data jadwal
        $this->jadwalModel->update($id, $data);

        // Redirect ke halaman jadwal setelah update
        return redirect()->to('jadwal/index');
    }

    public function delete($id)
    {
        $model = new JadwalModel();

        // Hapus data jadwal berdasarkan ID
        $model->delete($id);

        // Redirect atau beri response sesuai kebutuhan
        return redirect()->to('jadwal/index');
    }

    public function tambahJadwal()
    {
        // Ambil semua data lapangan
        $lapangan = $this->lapanganModel->findAll();

        return view('jadwal/tambah_jadwal', ['lapangan' => $lapangan]);
    }

    public function store()
    {
        $idLapangan = $this->request->getPost('id_lapangan');
        $tanggal = $this->request->getPost('tanggal');
        $jamMulaiArray = $this->request->getPost('jam_mulai'); // Array jam mulai
        $jamSelesaiArray = $this->request->getPost('jam_selesai'); // Array jam selesai
        $status = $this->request->getPost('status');

        // Simpan setiap rentang waktu sebagai jadwal baru
        foreach ($jamMulaiArray as $key => $jamMulai) {
            $jamSelesai = $jamSelesaiArray[$key];

            $this->jadwalModel->insert([
                'id_lapangan' => $idLapangan,
                'tanggal' => $tanggal,
                'jam_mulai' => $jamMulai,
                'jam_selesai' => $jamSelesai,
                'status' => $status,
            ]);
        }

        return redirect()->to(site_url('jadwal/index'))->with('message', 'Jadwal berhasil disimpan.');
    }
}
