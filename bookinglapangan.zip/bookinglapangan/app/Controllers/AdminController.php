<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class AdminController extends BaseController
{
    public function index(): string
    {
        return view('auth/login');
    }

    public function halamanAdmin()
    {
        $db = \Config\Database::connect();

        // Menghitung jumlah data dari tabel
        $jumlahLapangan = $db->table('lapangan')->countAllResults();
        $jumlahJadwal = $db->table('jadwal')->countAllResults();
        $jumlahPemesanan = $db->table('pemesanan')->countAllResults();

        return view('admin/halaman_admin', [
            'jumlahLapangan' => $jumlahLapangan,
            'jumlahJadwal' => $jumlahJadwal,
            'jumlahPemesanan' => $jumlahPemesanan
        ]);
    }

    public function profilAdmin()
    {
        $session = session();

        // Cek apakah sesi user ada
        if (!$session->has('user')) {
            return redirect()->to('/login/admin');
        }

        // Ambil data user dari sesi
        $user = $session->get('user');

        // Pastikan user memiliki role admin
        if ($user['role'] !== 'admin') {
            return redirect()->to('/login/admin')->with('error', 'Anda tidak memiliki akses ke halaman ini.');
        }

        return view('admin/profil_admin', ['user' => $user]);
    }

    public function editProfilAdmin()
    {
        $session = session();
        $user = $session->get('user');

        if (!$user || $user['role'] !== 'admin') {
            return redirect()->to('/login/admin')->with('error', 'Silakan login sebagai admin terlebih dahulu.');
        }

        return view('admin/edit_profil_admin', ['user' => $user]);
    }

    public function updateProfilAdmin()
    {
        $session = session();
        $user = $session->get('user');

        if (!$user || $user['role'] !== 'admin') {
            return redirect()->to('/login/admin')->with('error', 'Silakan login sebagai admin terlebih dahulu.');
        }

        $userModel = new UserModel();
        $id = $user['id_user']; // Asumsikan ada kolom ID dalam database user

        // Ambil data dari form
        $data = [
            'username' => $this->request->getPost('username'),
            'nama' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
        ];

        // Cek apakah password diubah
        $password = $this->request->getPost('password');
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        // Update data di database
        $userModel->update($id, $data);

        // Perbarui session dengan data yang baru
        $user['username'] = $data['username'];
        $user['nama'] = $data['nama'];
        $user['email'] = $data['email'];
        $session->set('user', $user);

        return redirect()->to('admin/edit_profil_admin')->with('success', 'Profil berhasil diperbarui.');
    }
}
