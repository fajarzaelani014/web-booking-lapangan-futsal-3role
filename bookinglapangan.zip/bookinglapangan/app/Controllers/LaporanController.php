<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use Config\Database;

class LaporanController extends BaseController
{
    public function pemesanan()
    {
        $db = \Config\Database::connect();

        // Ambil input filter dari GET
        $tanggal = $this->request->getGet('tanggal');
        $bulan   = $this->request->getGet('bulan');
        $tahun   = $this->request->getGet('tahun');

        // Siapkan query dasar
        $sql = "
        SELECT p.id_pemesanan, p.nama_pemesan, l.nama_lapangan, p.tanggal, p.jam_mulai, p.jam_selesai, l.harga_per_jam,
               (TIMESTAMPDIFF(HOUR, p.jam_mulai, p.jam_selesai) * l.harga_per_jam) AS total_harga
        FROM pemesanan p
        JOIN lapangan l ON p.id_lapangan = l.id_lapangan
        WHERE 1 = 1
    ";

        // Tambahkan filter jika tersedia
        if (!empty($tanggal)) {
            $sql .= " AND DATE(p.tanggal) = " . $db->escape($tanggal);
        }
        if (!empty($bulan)) {
            $sql .= " AND MONTH(p.tanggal) = " . $db->escape($bulan);
        }
        if (!empty($tahun)) {
            $sql .= " AND YEAR(p.tanggal) = " . $db->escape($tahun);
        }

        // Eksekusi query
        $query = $db->query($sql);
        $data['laporan'] = $query->getResultArray();

        // Kirim kembali nilai filter ke view agar tetap muncul di input
        $data['filter'] = [
            'tanggal' => $tanggal,
            'bulan' => $bulan,
            'tahun' => $tahun,
        ];

        return view('laporan/pemesanan', $data);
    }
}
