<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class ProfileController extends BaseController
{
    public function index()
    {
        if (!session()->has('user')) {
            return redirect()->to('/login/admin');
        }

        $userModel = new UserModel();
        $id_user = session('user')['id_user'];
        $user = $userModel->find($id_user); // Ambil data user dari DB

        return view('penyewa/profil', ['user' => $user]);
    }


    public function editProfil()
    {
        if (!session()->has('user')) {
            return redirect()->to('/login/admin');
        }

        $userModel = new UserModel();
        $id_user = session('user')['id_user'];
        $user = $userModel->find($id_user); // Ambil data terbaru

        return view('penyewa/edit_profil', ['user' => $user]);
    }

    public function updateProfil()
    {
        $session = session();
        $user = $session->get('user');

        if (!$user) {
            return redirect()->to('/login/admin')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userModel = new UserModel();
        $id = $user['id_user']; // Asumsikan ada kolom ID dalam database user

        // Ambil data dari form
        $data = [
            'username' => $this->request->getPost('username'),
            'nama' => $this->request->getPost('nama'), // Tambahkan nama
            'email' => $this->request->getPost('email'), // Tambahkan email
        ];

        // Cek apakah password diubah
        $password = $this->request->getPost('password');
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        // Update data di database
        $userModel->update($id, $data);

        // Perbarui session dengan data yang baru
        $user['username'] = $data['username'];
        $user['nama'] = $data['nama']; // Perbarui nama di session
        $user['email'] = $data['email']; // Perbarui email di session
        $session->set('user', $user);

        return redirect()->to('penyewa/edit_profil')->with('success', 'Profil berhasil diperbarui.');
    }
}
