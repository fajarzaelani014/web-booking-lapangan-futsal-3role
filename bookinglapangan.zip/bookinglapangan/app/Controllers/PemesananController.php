<?php

namespace App\Controllers;

use App\Models\PemesananModel;
use App\Models\JadwalModel;
use App\Models\LapanganModel;

class PemesananController extends BaseController
{
    // Fungsi untuk menampilkan halaman pemesanan
    public function halaman_pemesanan()
    {
        $pemesananModel = new PemesananModel();
        $jadwalModel = new JadwalModel();
        $lapanganModel = new LapanganModel();

        // Ambil filter dari input GET
        $id_lapangan = $this->request->getGet('id_lapangan');
        $tanggal = $this->request->getGet('tanggal');
        $bulan = $this->request->getGet('bulan');
        $tahun = $this->request->getGet('tahun');
        $perPage = $this->request->getGet('per_page') ?? 5; // Default 5 baris

        // Jika user memilih "Semua", set $perPage = null agar semua data ditampilkan
        if ($perPage == 'all') {
            $perPage = null;
        } else {
            $perPage = (int) $perPage; // Pastikan perPage tetap integer
        }

        // Query dengan filter
        $pemesananModel->select('pemesanan.*, lapangan.nama_lapangan, lapangan.harga_per_jam, jadwal.jam_mulai as jammulaijadwal, jadwal.jam_selesai as jamselesaijadwal')
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan', 'left')
            ->join('jadwal', 'jadwal.id_jadwal = pemesanan.id_jadwal', 'left');

        if (!empty($id_lapangan)) {
            $pemesananModel->where('pemesanan.id_lapangan', $id_lapangan);
        }
        if (!empty($tanggal)) {
            $pemesananModel->where('DATE(pemesanan.tanggal)', $tanggal);
        }
        if (!empty($bulan)) {
            $pemesananModel->where('MONTH(pemesanan.tanggal)', $bulan);
        }
        if (!empty($tahun)) {
            $pemesananModel->where('YEAR(pemesanan.tanggal)', $tahun);
        }

        // Pagination berdasarkan jumlah baris yang dipilih
        $data['pemesanan'] = $pemesananModel->paginate($perPage, 'pemesanan');
        $data['pager'] = $pemesananModel->pager;
        $data['lapangan'] = $lapanganModel->findAll();
        $data['perPage'] = $perPage ?? 'all'; // Kirim nilai perPage ke view

        return view('pemesanan/halaman_pemesanan', $data);
    }

    // Fungsi untuk menyimpan data pemesanan
    public function createPemesanan()
    {
        $pemesananModel = new PemesananModel();
        $lapanganModel = new LapanganModel();
        $jadwalModel = new JadwalModel();

        $id_lapangan = $this->request->getPost('id_lapangan');

        // Cek apakah id_lapangan ada di database
        $lapangan = $lapanganModel->find($id_lapangan);
        if (!$lapangan) {
            return redirect()->to('/pemesanan')->with('error', 'Lapangan tidak ditemukan.');
        }

        // Dapatkan jadwal berdasarkan id_lapangan (misalnya ambil jadwal pertama)
        $jadwal = $jadwalModel->where('id_lapangan', $id_lapangan)->first();

        // Cek apakah jadwal tersedia
        if (empty($jadwal['jam_mulai']) || empty($jadwal['jam_selesai'])) {
            return redirect()->to('/pemesanan')->with('error', 'Jadwal tidak lengkap.');
        }

        // Simpan pemesanan
        $pemesananModel->save([
            'id_lapangan' => $id_lapangan,
            'id_user' => session('user')['id_user'],
            'id_jadwal' => $this->request->getPost('id_jadwal'),
            'nama_pemesan' => $this->request->getPost('nama_pemesan'),
            'tanggal' => $this->request->getPost('tanggal'),
            'jam_mulai' => $jadwal['jam_mulai'], // Ambil jam_mulai dari jadwal
            'jam_selesai' => $jadwal['jam_selesai'], // Ambil jam_selesai dari jadwal
        ]);

        // Redirect ke halaman konfirmasi dengan membawa ID pemesanan
        return redirect()->to(site_url('pemesanan/konfirmasi/' . $pemesananModel->insertID()));
    }

    public function delete($id)
    {
        $pemesananModel = new \App\Models\PemesananModel();

        if ($pemesananModel->delete($id)) {
            return redirect()->to(site_url('pemesanan/halaman_pemesanan'))->with('success', 'Pemesanan berhasil dihapus.');
        } else {
            return redirect()->to(site_url('pemesanan/halaman_pemesanan'))->with('error', 'Gagal menghapus pemesanan.');
        }
    }

    public function konfirmasi($id)
    {
        $pemesananModel = new PemesananModel();
        $data['pemesanan'] = $pemesananModel->find($id);

        return view('pemesanan/konfirmasi', $data);
    }

    public function save()
    {
        $model = new PemesananModel();
        $jadwalModel = new JadwalModel();  // Membuat instance model Jadwal

        // Ambil data dari form input
        $id_jadwal = $this->request->getPost('id_jadwal');
        $data = [
            'id_lapangan' => $this->request->getPost('id_lapangan'),
            'id_user' => $this->request->getPost('id_user'),  // Menyimpan ID User
            'id_jadwal' => $id_jadwal,  // Menyimpan ID Jadwal
            'nama_pemesan' => $this->request->getPost('nama_pemesan'),
            'tanggal' => $this->request->getPost('tanggal'),
            'status' => 'Pending',  // Status default
        ];

        // Ambil jam_mulai dan jam_selesai dari tabel jadwal berdasarkan id_jadwal
        $jadwal = $jadwalModel->find($id_jadwal);  // Cari jadwal berdasarkan id_jadwal

        // Pastikan jadwal ditemukan
        if ($jadwal) {
            $data['jam_mulai'] = $jadwal['jam_mulai'];  // Set jam_mulai dari jadwal
            $data['jam_selesai'] = $jadwal['jam_selesai'];  // Set jam_selesai dari jadwal
        } else {
            // Jika jadwal tidak ditemukan, set default jam_mulai dan jam_selesai
            $data['jam_mulai'] = '00:00';  // Jam default jika jadwal tidak ditemukan
            $data['jam_selesai'] = '00:00';  // Jam default jika jadwal tidak ditemukan
        }

        // Simpan data ke database
        $model->save($data);

        return redirect()->to('/pemesanan');  // Redirect ke halaman pemesanan
    }


    public function pembayaran($id_lapangan)
    {
        $jadwalModel = new JadwalModel();

        // Ambil jadwal berdasarkan id_lapangan
        $jadwal = $jadwalModel->where('id_lapangan', $id_lapangan)->first();

        // Cek apakah jadwal ditemukan
        if (!$jadwal) {
            return redirect()->to('/lapangan')->with('error', 'Jadwal tidak ditemukan.');
        }

        // Kirim data ke view
        return view('pembayaran/pembayaran', [
            'jadwal' => $jadwal
        ]);
    }

    public function cetak($id)
    {
        $model = new PemesananModel();
        $data['pemesanan'] = $model->select('pemesanan.*, lapangan.nama_lapangan, lapangan.harga_per_jam, jadwal.jam_mulai as jammulaijadwal, jadwal.jam_selesai as jamselesaijadwal')
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan')
            ->join('jadwal', 'jadwal.id_jadwal = pemesanan.id_jadwal')
            ->where('id_pemesanan', $id)
            ->first();

        return view('pemesanan/cetak', $data);
    }
}
