<?php

namespace App\Controllers;

use App\Models\LapanganModel; // Import model

class LapanganController extends BaseController
{
    protected $lapanganModel;

    public function __construct()
    {
        $this->lapanganModel = new LapanganModel();
    }

    // Method untuk menampilkan data lapangan
    public function data_lapangan()
    {
        // Ambil semua data lapangan
        $data['lapangan'] = $this->lapanganModel->findAll();
        return view('lapangan/data_lapangan', $data);
    }

    // Method untuk menampilkan halaman create lapangan
    public function create()
    {
        $lapanganModel = new LapanganModel();
        $data['lapangan'] = $lapanganModel->findAll(); // Pastikan tabel lapangan memiliki data
        return view('lapangan/create_lapangan', $data);
    }


    // Method untuk menyimpan data lapangan
    public function store()
    {
        // Ambil harga dari input form
        $harga = $this->request->getPost('harga_per_jam');

        // Cek jika harga negatif
        if ($harga < 0) {
            return redirect()->back()->withInput()->with('error', 'Harga tidak boleh negatif!');
        }

        // Ambil data lain dari form
        $data = [
            'nama_lapangan' => $this->request->getPost('nama_lapangan'),
            'fasilitas' => $this->request->getPost('fasilitas'),
            'deskripsi' => $this->request->getPost('deskripsi'),
            'harga_per_jam' => $harga, // Harga sudah dipastikan tidak negatif
        ];

        // Cek apakah ada foto yang diupload
        $foto = $this->request->getFile('foto');
        if ($foto && !$foto->hasMoved() && $foto->isValid()) {
            $filefoto = $foto->getRandomName();
            $foto->move('uploads', $filefoto);
            $data['foto'] = $filefoto;
        }

        // Insert data lapangan ke database
        $this->lapanganModel->insert($data);

        // Redirect setelah sukses
        return redirect()->to('/lapangan/data_lapangan')->with('success', 'Lapangan berhasil ditambahkan!');
    }

    public function delete($id)
    {
        $lapangan = $this->lapanganModel->find($id);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data lapangan dengan ID $id tidak ditemukan.");
        }

        // Hapus file foto jika ada
        if (!empty($lapangan['foto'])) {
            $fotoPath = WRITEPATH . 'uploads/' . $lapangan['foto'];
            if (is_file($fotoPath)) {
                unlink($fotoPath); // Hapus file
            }
        }

        // Hapus data dari database
        $this->lapanganModel->delete($id);

        return redirect()->to('/lapangan/data_lapangan')->with('success', 'Data berhasil dihapus.');
    }

    public function edit($id)
    {
        $lapangan = $this->lapanganModel->find($id);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data lapangan dengan ID $id tidak ditemukan.");
        }

        return view('lapangan/edit', ['lapangan' => $lapangan]);
    }

    public function update($id)
    {
        $lapangan = $this->lapanganModel->find($id);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data lapangan dengan ID $id tidak ditemukan.");
        }

        $foto = $this->request->getFile('foto');
        if ($foto->getError() == 4) {
        } else {
            $filefoto = $foto->getRandomName();
            $foto->move('uploads', $filefoto);
            $lapangan['foto'] = $filefoto;
        }

        // Update data
        $lapangan['nama_lapangan'] = $this->request->getPost('nama_lapangan');
        $lapangan['fasilitas'] = $this->request->getPost('fasilitas');
        $lapangan['deskripsi'] = $this->request->getPost('deskripsi');
        $lapangan['harga_per_jam'] = $this->request->getPost('harga_per_jam');
        $this->lapanganModel->update($id, $lapangan);

        return redirect()->to('/lapangan/data_lapangan')->with('success', 'Data berhasil diperbarui.');
    }

    public function upload()
    {
        $file = $this->request->getFile('foto');

        if ($file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(WRITEPATH . '../public/uploads/', $newName);

            // Simpan ke database
            $data = [
                'id_lapangan' => $this->request->getPost('id_lapangan'),
                'foto' => $newName,
                'nama_lapangan' => $this->request->getPost('nama_lapangan'),
                'fasilitas' => $this->request->getPost('fasilitas'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'harga_per_jam' => $this->request->getPost('harga_per_jam'),
            ];
            $this->lapanganModel->insert($data);

            return redirect()->to('/lapangan');
        } else {
            return redirect()->back()->with('error', 'Gagal upload foto.');
        }
    }
}
