<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class UserController extends Controller
{
    public function index()
    {
        $userModel = new UserModel();

        // Ambil peran dari query string (default: 'semua')
        $role = $this->request->getGet('role') ?? 'semua';

        // Jika peran tidak "semua", lakukan filter berdasarkan role
        if ($role !== 'semua') {
            $data['user'] = $userModel->where('role', $role)->findAll();
        } else {
            $data['user'] = $userModel->findAll(); // Tampilkan semua pengguna
        }

        // Kirim peran yang dipilih ke view
        $data['selectedRole'] = $role;

        return view('user/index', $data);
    }

    public function edit($id)
    {
        $userModel = new UserModel();
        $data['user'] = $userModel->find($id);

        if (!$data['user']) {
            return redirect()->to('/user')->with('error', 'User tidak ditemukan');
        }

        return view('user/edit', $data);
    }

    public function update($id)
    {
        $userModel = new UserModel();

        $data = [
            'username' => $this->request->getPost('username'),
            'nama' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
            'role' => $this->request->getPost('role'),
        ];

        $userModel->update($id, $data);
        return redirect()->to('/user')->with('success', 'User berhasil diperbarui');
    }

    public function delete($id)
    {
        $userModel = new UserModel();
        $userModel->delete($id);

        return redirect()->to('/user')->with('success', 'User berhasil dihapus');
    }
}
