<?php

namespace App\Controllers;

use App\Models\PengelolaModel;
use App\Models\LapanganModel;
use App\Models\PemesananModel;
use App\Models\JadwalModel;

class PengelolaController extends BaseController
{
    protected $lapanganModel;
    protected $pengelolaModel;

    public function __construct()
    {
        $this->lapanganModel = new LapanganModel();
        $this->pengelolaModel = new PengelolaModel();
    }

    public function halamanPengelola()
    {
        $data['lapangan'] = $this->lapanganModel->findAll();
        return view('pengelola/halaman_pengelola', $data);
    }

    public function tambahPengelola()
    {
        return view('pengelola/tambah_pengelola');
    }

    public function store()
    {
        // Ambil data dari form
        $data = [
            'nama_lapangan' => $this->request->getPost('nama_lapangan'),
            'fasilitas' => $this->request->getPost('fasilitas'),
            'deskripsi' => $this->request->getPost('deskripsi'),
            'harga_per_jam' => $this->request->getPost('harga_per_jam'),
        ];

        // Ambil file foto
        $foto = $this->request->getFile('foto');

        // Periksa apakah file valid
        if ($foto && !$foto->hasMoved() && $foto->isValid()) {
            $filefoto = $foto->getRandomName();
            $foto->move('uploads', $filefoto);
            $data['foto'] = $filefoto;
        }

        // Simpan data ke database
        $this->lapanganModel->insert($data);

        // Redirect ke halaman pengelola setelah sukses
        return redirect()->to('/pengelola/halaman_pengelola')->with('success', 'Lapangan berhasil ditambahkan!');
    }



    public function editPengelola($id)
    {
        $pengelola = $this->pengelolaModel->find($id);
        $lapangan = $this->lapanganModel->find($id); // Pastikan data lapangan diambil juga

        if (!$pengelola || !$lapangan) {
            return redirect()->to('/pengelola')->with('error', 'Data tidak ditemukan');
        }

        $data = [
            'pengelola' => $pengelola,
            'lapangan' => $lapangan
        ];

        return view('pengelola/edit_pengelola', $data);
    }

    public function updatePengelola($id)
    {
        $lapangan = $this->lapanganModel->find($id);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data lapangan dengan ID $id tidak ditemukan.");
        }

        // Ambil file foto dari request
        $foto = $this->request->getFile('foto');

        // Periksa apakah ada file yang diunggah dan valid
        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            $filefoto = $foto->getRandomName();
            $foto->move('uploads', $filefoto);
            $lapangan['foto'] = $filefoto;
        }

        // Update data lainnya
        $lapangan['nama_lapangan'] = $this->request->getPost('nama_lapangan');
        $lapangan['fasilitas'] = $this->request->getPost('fasilitas');
        $lapangan['deskripsi'] = $this->request->getPost('deskripsi');
        $lapangan['harga_per_jam'] = $this->request->getPost('harga_per_jam');

        // Simpan ke database
        $this->lapanganModel->update($id, $lapangan);

        // Redirect ke halaman pengelola setelah berhasil update
        return redirect()->to('/pengelola/halaman_pengelola')->with('success', 'Data berhasil diperbarui.');
    }

    public function delete($id)
    {
        $pengelola = $this->pengelolaModel->find($id);

        if (!$pengelola) {
            return redirect()->to('/pengelola/halaman_pengelola')->with('error', 'Data tidak ditemukan.');
        }

        // Hapus data dari database
        $this->pengelolaModel->delete($id);

        return redirect()->to('/pengelola/halaman_pengelola')->with('success', 'Data berhasil dihapus.');
    }

    public function laporan_pengelola()
    {
        $pemesananModel = new PemesananModel();
        $jadwalModel = new JadwalModel();
        $lapanganModel = new LapanganModel();

        // Ambil filter dari input GET
        $id_lapangan = $this->request->getGet('id_lapangan');
        $tanggal = $this->request->getGet('tanggal');
        $bulan = $this->request->getGet('bulan');
        $tahun = $this->request->getGet('tahun');
        $perPage = $this->request->getGet('per_page') ?? 5; // Default 5 baris

        // Jika user memilih "Semua", set $perPage = null agar semua data ditampilkan
        if ($perPage == 'all') {
            $perPage = null;
        } else {
            $perPage = (int) $perPage; // Pastikan perPage tetap integer
        }

        // Query dengan filter
        $pemesananModel->select('pemesanan.*, lapangan.nama_lapangan, lapangan.harga_per_jam, jadwal.jam_mulai as jammulaijadwal, jadwal.jam_selesai as jamselesaijadwal')
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan', 'left')
            ->join('jadwal', 'jadwal.id_jadwal = pemesanan.id_jadwal', 'left');

        if (!empty($id_lapangan)) {
            $pemesananModel->where('pemesanan.id_lapangan', $id_lapangan);
        }
        if (!empty($tanggal)) {
            $pemesananModel->where('DATE(pemesanan.tanggal)', $tanggal);
        }
        if (!empty($bulan)) {
            $pemesananModel->where('MONTH(pemesanan.tanggal)', $bulan);
        }
        if (!empty($tahun)) {
            $pemesananModel->where('YEAR(pemesanan.tanggal)', $tahun);
        }

        // Pagination berdasarkan jumlah baris yang dipilih
        $data['pemesanan'] = $pemesananModel->paginate($perPage, 'pemesanan');
        $data['pager'] = $pemesananModel->pager;
        $data['lapangan'] = $lapanganModel->findAll();
        $data['perPage'] = $perPage ?? 'all'; // Kirim nilai perPage ke view

        return view('pengelola/laporan_pengelola', $data);
    }

    public function homePengelola()
    {
        return view('pengelola/home_pengelola');
    }
}
