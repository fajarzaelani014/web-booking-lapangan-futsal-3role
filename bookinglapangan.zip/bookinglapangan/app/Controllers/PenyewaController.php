<?php

namespace App\Controllers;

use App\Models\JadwalModel;
use App\Models\PemesananModel;
use App\Models\PenyewaModel;
use App\Models\LapanganModel; // Import model Lapangan

class PenyewaController extends BaseController
{
    protected $lapanganModel;

    public function __construct()
    {
        $this->lapanganModel = new LapanganModel();
    }

    public function halamanPenyewa()
    {
        // Ambil data lapangan
        $lapanganModel = new \App\Models\LapanganModel();
        $data['lapangan'] = $lapanganModel->findAll();

        // Ambil data pemesanan untuk setiap lapangan
        $pemesananModel = new \App\Models\PemesananModel();
        foreach ($data['lapangan'] as &$item) {
            $item['pemesanan'] = $pemesananModel->where('id_lapangan', $item['id_lapangan'])->findAll();
        }

        return view('penyewa/halaman_penyewa', $data);
    }

    public function halamanAwal()
    {
        $lapanganModel = new LapanganModel();
        $data['lapangan'] = $lapanganModel->findAll(); // Ambil semua data lapangan dari database

        return view('penyewa/halaman_awal', $data); // Kirim data ke view
    }

    public function booking($id_lapangan)
    {
        // Ambil data lapangan berdasarkan ID
        $lapangan = $this->lapanganModel->find($id_lapangan);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Lapangan dengan ID $id_lapangan tidak ditemukan.");
        }

        // Kirim data ke view untuk halaman booking
        return view('penyewa/booking_lapangan', ['lapangan' => $lapangan]);
    }

    public function homePenyewa()
    {
        // Render view untuk halaman home penyewa
        return view('penyewa/home_penyewa');
    }

    public function detail($id_lapangan)
    {
        $lapanganModel = new \App\Models\LapanganModel();
        $lapangan = $lapanganModel->find($id_lapangan);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Lapangan tidak ditemukan');
        }

        return view('penyewa/detail', ['lapangan' => $lapangan]);
    }

    public function detail_awal($id_lapangan)
    {
        $lapanganModel = new \App\Models\LapanganModel();
        $lapangan = $lapanganModel->find($id_lapangan);

        if (!$lapangan) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Lapangan tidak ditemukan');
        }

        return view('penyewa/detail_awal', ['lapangan' => $lapangan]);
    }


    public function bookingLapangan($id)
    {
        // Ambil data lapangan berdasarkan ID
        $lapanganModel = new LapanganModel();
        $lapangan = $lapanganModel->find($id);

        if ($lapangan) {
            // Ambil data jadwal lapangan
            $jadwalModel = new JadwalModel();
            $jadwal = $jadwalModel->getJadwalByLapangan($id);

            // Ambil data pemesanan untuk jadwal yang tersedia
            $pemesananModel = new PemesananModel();
            $pemesanan = $pemesananModel->where('id_lapangan', $id)->findAll();

            // Ambil daftar tanggal yang tersedia berdasarkan pemesanan
            $tanggal_tersedia = $pemesananModel->where('id_lapangan', $id)
                ->select('tanggal')
                ->distinct()
                ->findAll();

            return view('penyewa/booking_lapangan', [
                'lapangan'          => $lapangan,
                'jadwal'            => $jadwal,
                'pemesanan'         => $pemesanan,
                'tanggal_tersedia'  => $tanggal_tersedia // Tambahkan tanggal tersedia ke view
            ]);
        } else {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Lapangan dengan ID $id tidak ditemukan.");
        }
    }

    public function riwayat()
    {
        $model = new PemesananModel();
        $id_user = session('user')['id_user']; // ambil ID user dari session

        $data['riwayat'] = $model
            ->select('
            pemesanan.id_pemesanan,
            lapangan.nama_lapangan,
            lapangan.harga_per_jam,
            pemesanan.tanggal,
            pemesanan.nama_pemesan
        ')
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan')
            ->where('pemesanan.id_user', $id_user) // filter berdasarkan user login
            ->orderBy('pemesanan.tanggal', 'DESC') // urutkan dari terbaru
            ->findAll();

        return view('penyewa/riwayat', $data);
    }
}
