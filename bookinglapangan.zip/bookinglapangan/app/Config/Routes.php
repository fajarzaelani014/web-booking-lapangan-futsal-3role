<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes 
 */
//$routes->get('/', 'AdminController::index');
$routes->get('/', 'PenyewaController::halamanAwal'); // Arahkan ke halamanAwal saat membuka aplikasi
$routes->get('penyewa/halaman_awal', 'PenyewaController::halamanAwal'); // Rute langsung ke halaman_awal


//JADWAL
$routes->get('jadwal/index', 'JadwalController::index');
$routes->get('jadwal/tambah_jadwal', 'JadwalController::tambahJadwal');
$routes->post('jadwal/store', 'JadwalController::store');
$routes->get('jadwal/edit/(:segment)', 'JadwalController::edit/$1');
$routes->post('jadwal/update/(:segment)', 'JadwalController::update/$1');
$routes->get('jadwal/delete/(:segment)', 'JadwalController::delete/$1');


//LAPANGAN
$routes->get('admin/halaman_admin', 'AdminController::halamanAdmin');
$routes->get('lapangan/data_lapangan', 'LapanganController::data_lapangan');
$routes->get('lapangan/create_lapangan', 'LapanganController::create');
$routes->post('lapangan/store', 'LapanganController::store');
$routes->get('lapangan/delete/(:num)', 'LapanganController::delete/$1');
$routes->get('lapangan/edit/(:num)', 'LapanganController::edit/$1');
$routes->post('lapangan/update/(:num)', 'LapanganController::update/$1');



//PEMESANAN 
$routes->get('pemesanan/halaman_pemesanan', 'PemesananController::halaman_pemesanan');
$routes->get('checkout/(:segment)', 'PemesananController::halaman_checkout/$1');
$routes->post('pemesanan/createPemesanan', 'PemesananController::createPemesanan');
$routes->get('pemesanan/konfirmasi', 'PemesananController::konfirmasi');
$routes->get('halaman_pemesanan', 'PemesananController::halaman_pemesanan');
$routes->get('pemesanan', 'PemesananController::halaman_pemesanan');
$routes->get('/pemesanan', 'PemesananController::halaman_pemesanan');
$routes->post('/pemesanan/konfirmasi', 'PemesananController::konfirmasi');
$routes->get('pemesanan/konfirmasi/(:num)', 'PemesananController::konfirmasi/$1');
$routes->get('pemesanan/delete/(:num)', 'PemesananController::delete/$1');



//LOGIN
$routes->get('login/admin', 'AuthController::login');
$routes->post('auth/loginProcess', 'AuthController::loginProcess');
$routes->get('auth/login', 'AuthController::login');


//REGISTER
$routes->get('/auth/register', 'AuthController::register'); // Route untuk halaman register
$routes->post('/auth/register', 'AuthController::registerProcess'); // Route untuk proses register
$routes->get('/login/admin', 'AuthController::login'); // Route untuk halaman login
$routes->post('/auth/loginProcess', 'AuthController::loginProcess'); // Route untuk proses login


//PENYEWA
$routes->get('penyewa/halaman_penyewa', 'PenyewaController::halamanPenyewa');
$routes->get('/penyewa', 'PenyewaController::halamanPenyewa');
$routes->get('/penyewa/home_penyewa', 'PenyewaController::homePenyewa');
$routes->get('penyewa/detail/(:num)', 'PenyewaController::detail/$1');
$routes->get('penyewa/booking/(:num)', 'PenyewaController::booking/$1');
$routes->get('penyewa/detail/(:segment)', 'PenyewaController::detailLapangan/$1');
$routes->get('penyewa/booking_lapangan/(:num)', 'PenyewaController::bookingLapangan/$1');
$routes->get('penyewa/detail_awal/(:num)', 'PenyewaController::detail_awal/$1');


//PENGELOLA
$routes->get('pengelola/tambah_pengelola', 'PengelolaController::tambahPengelola');
$routes->get('pengelola/edit_pengelola/(:num)', 'PengelolaController::editPengelola/$1');
$routes->post('pengelola/updatePengelola/(:num)', 'PengelolaController::updatePengelola/$1');
$routes->get('/pengelola/halaman_pengelola', 'PengelolaController::halamanPengelola');
$routes->post('/pengelola/delete/(:num)', 'PengelolaController::delete/$1');
$routes->post('pengelola/store', 'PengelolaController::store');
$routes->get('pengelola/laporan_pengelola', 'PengelolaController::laporan_pengelola');
$routes->get('pengelola/home_pengelola', 'PengelolaController::homePengelola');


//CHECKOUT
$routes->get('pembayaran/halaman_checkout', 'PembayaranController::checkout');
$routes->get('pembayaran/pembayaran', 'PembayaranController::pembayaran');


//LIGA AYO
$routes->get('liga/liga_ayo', 'LigaController::liga_ayo');


//LOGIN
$routes->get('login/admin', 'AuthController::login');
$routes->post('auth/loginProcess', 'AuthController::loginProcess');
$routes->get('auth/login', 'AuthController::login');
$routes->post('auth/registerProcess', 'AuthController::registerProcess');
$routes->get('pengelola/halaman_pengelola', 'PengelolaController::halamanPengelola');


//REGISTER
$routes->get('/auth/register', 'AuthController::register'); // Route untuk halaman register
$routes->post('/auth/register', 'AuthController::registerProcess'); // Route untuk proses register
$routes->get('/login/admin', 'AuthController::login'); // Route untuk halaman login
$routes->post('/auth/loginProcess', 'AuthController::loginProcess'); // Route untuk proses login


//LOGOUT
$routes->get('/logout', 'AuthController::logout');


//CETAK
$routes->get('pemesanan/cetak/(:num)', 'PemesananController::cetak/$1');


//LAPORAN
$routes->get('laporan/pemesanan', 'LaporanController::pemesanan');
$routes->get('laporan/pemesanan', 'LaporanController::laporanPemesanan');


//Profile
$routes->get('/penyewa/profil', 'ProfileController::index');
$routes->get('penyewa/edit_profil', 'ProfileController::editProfil');
$routes->post('penyewa/update_profil', 'ProfileController::updateProfil');


//User
$routes->get('user/index', 'UserController::index');
$routes->get('/user', 'UserController::index');
$routes->get('/user/edit/(:num)', 'UserController::edit/$1');
$routes->post('/user/update/(:num)', 'UserController::update/$1');
$routes->get('/user/delete/(:num)', 'UserController::delete/$1');


//Admin
$routes->get('admin/profil_admin', 'AdminController::profilAdmin');
$routes->get('admin/edit_profil_admin', 'AdminController::editProfilAdmin');
$routes->post('admin/update_profil_admin', 'AdminController::updateProfilAdmin');


//Keuangan
$routes->get('pengelola/keuangan', 'KeuanganController::index');


//RIWAYAT
$routes->get('penyewa/riwayat', 'PenyewaController::riwayat');
$routes->get('penyewa/riwayat/(:num)', 'PenyewaController::riwayat/$1');
