<?php

namespace App\Models;

use CodeIgniter\Model;

class KeuanganModel extends Model
{
    protected $table = 'pemesanan';

    public function getKeuangan()
    {
        return $this->db->table('pemesanan')
            ->select('pemesanan.id_pemesanan, lapangan.nama_lapangan, lapangan.harga_per_jam, pemesanan.tanggal') // Tambahkan tanggal
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan')
            ->get()->getResultArray();
    }
}
