<?php

namespace App\Models;

use CodeIgniter\Model;

class PengelolaModel extends Model
{
    protected $table = 'lapangan'; // Menggunakan tabel 'lapangan'
    protected $primaryKey = 'id_lapangan'; // Primary key tabel lapangan
    protected $allowedFields = ['nama_lapangan', 'foto', 'fasilitas', 'deskripsi', 'harga_per_jam']; // Sesuaikan dengan tabel
}
