<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'id_user';
    protected $allowedFields = ['username', 'password', 'nama', 'email', 'role'];

    // Ambil semua admin
    public function getAdmins()
    {
        return $this->where('role', 'admin')->findAll();
    }

    // Ambil semua pengelola
    public function getPengelola()
    {
        return $this->where('role', 'pengelola')->findAll();
    }

    // Ambil semua penyewa
    public function getPenyewa()
    {
        return $this->where('role', 'penyewa')->findAll();
    }
}
