<?php

namespace App\Models;

use CodeIgniter\Model;

class LapanganModel extends Model
{
    protected $table = 'lapangan'; // Nama tabel di database
    protected $primaryKey = 'id_lapangan'; // Primary key tabel
    protected $allowedFields = ['nama_lapangan', 'foto', 'fasilitas', 'deskripsi', 'harga_per_jam']; // Kolom yang boleh diisi
}
