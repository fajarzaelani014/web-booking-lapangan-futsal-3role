<?php

namespace App\Models;

use CodeIgniter\Model;

class PemesananModel extends Model
{
    protected $table = 'pemesanan';
    protected $primaryKey = 'id_pemesanan';
    protected $allowedFields = ['id_lapangan', 'id_user', 'id_jadwal', 'nama_pemesan', 'tanggal', 'jam_mulai', 'jam_selesai', 'status'];

    public function getPemesanan()
    {
        return $this->db->table('pemesanan')
            ->select('pemesanan.*, lapangan.nama_lapangan') // Ambil nama_lapangan dari tabel lapangan
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan', 'left')
            ->get()->getResultArray();
    }

    public function getKeuangan($tanggal = null, $bulan = null, $tahun = null)
    {
        $builder = $this->db->table('pemesanan')
            ->select('pemesanan.id_pemesanan, pemesanan.tanggal, lapangan.nama_lapangan, lapangan.harga_per_jam')
            ->join('lapangan', 'lapangan.id_lapangan = pemesanan.id_lapangan');

        // Filter berdasarkan tanggal
        if (!empty($tanggal)) {
            $builder->where('pemesanan.tanggal', $tanggal);
        }

        // Filter berdasarkan bulan
        if (!empty($bulan)) {
            $builder->where('MONTH(pemesanan.tanggal)', $bulan);
        }

        // Filter berdasarkan tahun
        if (!empty($tahun)) {
            $builder->where('YEAR(pemesanan.tanggal)', $tahun);
        }

        return $builder->get()->getResultArray();
    }
}
