<?php

namespace App\Models;

use CodeIgniter\Model;

class JadwalModel extends Model
{
    protected $table = 'jadwal';
    protected $primaryKey = 'id_jadwal';
    protected $allowedFields = ['id_lapangan', 'tanggal', 'jam_mulai', 'jam_selesai', 'status'];

    public function getJadwalWithLapangan()
    {
        return $this->db->table($this->table)
            ->join('lapangan', 'lapangan.id_lapangan = jadwal.id_lapangan') // Melakukan join dengan tabel lapangan
            ->select('jadwal.*, lapangan.nama_lapangan, lapangan.foto') // Mengambil semua data jadwal + nama_lapangan + foto
            ->get()
            ->getResultArray();
    }

    public function getJadwalWithLapanganByLapangan($id_lapangan)
    {
        return $this->db->table($this->table)
            ->join('lapangan', 'lapangan.id_lapangan = jadwal.id_lapangan') // Join dengan tabel lapangan
            ->where('jadwal.id_lapangan', $id_lapangan) // Filter berdasarkan id_lapangan
            ->select('jadwal.*, lapangan.nama_lapangan') // Ambil data jadwal + nama lapangan
            ->get()
            ->getResultArray();
    }

    // Fungsi untuk mengambil data jadwal berdasarkan id_lapangan
    public function getJadwalByLapangan($id_lapangan)
    {
        return $this->db->table('jadwal')
            ->join('lapangan', 'lapangan.id_lapangan = jadwal.id_lapangan')
            ->where('jadwal.id_lapangan', $id_lapangan)
            ->get()
            ->getResultArray();
    }
}
